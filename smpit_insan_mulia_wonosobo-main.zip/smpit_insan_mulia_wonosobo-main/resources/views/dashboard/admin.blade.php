@extends('layouts.admin')

@section('title', 'Dashboard Admin - SIAKAD SMPIT Insan Mulia Wonosobo')

@section('content')
    <div
        class="mb-8 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm">
        <div>
            <h2 class="text-2xl font-extrabold text-slate-900 tracking-tight">Selamat Datang, {{ auth()->user()->name }}
            </h2>
            <p class="text-sm text-slate-500 mt-1">Sistem Informasi Akademik SMPIT Insan Mulia Wonosobo.</p>
        </div>
        <div class="hidden sm:block">
            <span
                class="px-4 py-2 rounded-xl bg-emerald-50 text-emerald-800 text-xs font-bold border border-emerald-200 block">
                Tahun Ajaran: {{ $tahunAktif->nama ?? 'Belum diset' }}
            </span>
        </div>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
        <div class="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm">
            <span class="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-1">Data Master</span>
            <p class="text-sm font-medium text-slate-600">Total Kelas</p>
            <div class="flex items-baseline justify-between mt-2">
                <h3 class="text-3xl font-extrabold text-emerald-700">{{ $totalKelas }}</h3>
                <a href="{{ route('admin.classrooms.index') }}"
                    class="text-xs font-semibold text-emerald-700 hover:underline">Kelola &rarr;</a>
            </div>
        </div>

        <div class="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm">
            <span class="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-1">SDM Pengajar</span>
            <p class="text-sm font-medium text-slate-600">Total Guru</p>
            <div class="flex items-baseline justify-between mt-2">
                <h3 class="text-3xl font-extrabold text-emerald-700">{{ $totalGuru }}</h3>
                <a href="{{ route('admin.teachers.index') }}"
                    class="text-xs font-semibold text-emerald-700 hover:underline">Kelola &rarr;</a>
            </div>
        </div>

        <div class="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm">
            <span class="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-1">Peserta Didik</span>
            <p class="text-sm font-medium text-slate-600">Siswa Aktif</p>
            <div class="flex items-baseline justify-between mt-2">
                <h3 class="text-3xl font-extrabold text-emerald-600">{{ $totalSiswa }}</h3>
                <a href="{{ route('admin.students.index') }}"
                    class="text-xs font-semibold text-emerald-600 hover:underline">Kelola &rarr;</a>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-2xl border border-slate-200/80 shadow-sm p-6">
        <h3 class="text-base font-bold text-slate-900 mb-4">Akses Cepat Modul Administrasi</h3>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <a href="{{ route('admin.schedules.index') }}"
                class="p-4 rounded-xl border border-slate-200 hover:border-emerald-500 hover:bg-emerald-50/30 transition group">
                <span class="text-xs font-bold text-emerald-700 uppercase tracking-wider block mb-1">Penjadwalan</span>
                <h4 class="text-sm font-bold text-slate-900 group-hover:text-emerald-800">Jadwal Pelajaran</h4>
                <p class="text-xs text-slate-500 mt-1">Atur alokasi jam mengajar dan pengampu kelas.</p>
            </a>

            <a href="{{ route('admin.attendances.index') }}"
                class="p-4 rounded-xl border border-slate-200 hover:border-emerald-500 hover:bg-emerald-50/30 transition group">
                <span class="text-xs font-bold text-emerald-700 uppercase tracking-wider block mb-1">Presensi</span>
                <h4 class="text-sm font-bold text-slate-900 group-hover:text-emerald-800">Rekap Kehadiran</h4>
                <p class="text-xs text-slate-500 mt-1">Pencatatan dan analisis presensi harian siswa.</p>
            </a>

            <a href="{{ route('admin.kekhasan.index') }}"
                class="p-4 rounded-xl border border-slate-200 hover:border-emerald-500 hover:bg-emerald-50/30 transition group">
                <span class="text-xs font-bold text-emerald-600 uppercase tracking-wider block mb-1">Akademik</span>
                <h4 class="text-sm font-bold text-slate-900 group-hover:text-emerald-800">Input & Pengolahan Nilai</h4>
                <p class="text-xs text-slate-500 mt-1">Kelola nilai tugas, harian, UTS, hingga UAS.</p>
            </a>

            <a href="{{ route('admin.reports.index') }}"
                class="p-4 rounded-xl border border-slate-200 hover:border-emerald-500 hover:bg-emerald-50/30 transition group">
                <span class="text-xs font-bold text-emerald-600 uppercase tracking-wider block mb-1">Cetak</span>
                <h4 class="text-sm font-bold text-slate-900 group-hover:text-emerald-800">Laporan Raport</h4>
                <p class="text-xs text-slate-500 mt-1">Generasi dokumen lembar hasil belajar siswa.</p>
            </a>
        </div>
    </div>
@endsection