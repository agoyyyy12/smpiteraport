<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SIAKAD - SMPIT Insan Mulia Wonosobo</title>
    @if (file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot')))
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    @else
    <script src="https://cdn.tailwindcss.com"></script>
    @endif
</head>

<body class="bg-emerald-50/40 text-slate-800 font-sans antialiased min-h-screen flex flex-col justify-between">
    <header class="w-full max-w-7xl mx-auto px-6 py-6 flex items-center justify-between">
        <div class="flex items-center space-x-3">
            <img src="{{ asset('images/logo.webp') }}" alt="Logo SMPIT Insan Mulia" class="w-10 h-10 object-contain">
            <div>
                <span class="font-bold text-slate-900 text-base tracking-tight block leading-none">SMPIT Insan
                    Mulia</span>
                <span class="text-xs text-emerald-700 font-semibold">Wonosobo</span>
            </div>
        </div>

        @if (Route::has('login'))
        <nav class="flex items-center space-x-3">
            @auth
            <a href="{{ url('/home') }}"
                class="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold transition shadow-sm">
                Dashboard
            </a>
            @else
            <a href="{{ route('login') }}"
                class="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold transition shadow-sm">
                Masuk Sistem
            </a>
            @endauth
        </nav>
        @endif
    </header>

    <main class="w-full max-w-7xl mx-auto px-6 py-12 lg:py-20 flex-1 flex flex-col justify-center">
        <div class="max-w-3xl mx-auto text-center space-y-6">
            <span
                class="inline-block px-4 py-1.5 rounded-full bg-emerald-100 text-emerald-800 text-xs font-semibold uppercase tracking-wider border border-emerald-200">
                Sistem Informasi Akademik
            </span>

            <h1 class="text-4xl md:text-6xl font-extrabold text-slate-900 tracking-tight leading-tight">
                Mewujudkan Tata Kelola Akademik yang Terintegrasi & Modern
            </h1>

            <p class="text-lg md:text-xl text-slate-600 leading-relaxed font-normal max-w-2xl mx-auto">
                Platform resmi pengelolaan data pembelajaran, jadwal, presensi, dan penilaian siswa SMPIT Insan Mulia
                Wonosobo.
            </p>

            <div class="pt-4 flex flex-col sm:flex-row justify-center items-center gap-4">
                @auth
                <a href="{{ url('/home') }}"
                    class="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-base transition shadow-md">
                    Buka Dashboard
                </a>
                @else
                <a href="{{ route('login') }}"
                    class="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-base transition shadow-md">
                    Masuk ke Portal
                </a>
                @endauth
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16 max-w-5xl mx-auto w-full">
            <div class="bg-white p-6 rounded-2xl border border-emerald-100 shadow-sm">
                <div class="text-xs font-bold text-emerald-600 uppercase tracking-wider mb-2">01. Pembelajaran</div>
                <h2 class="text-lg font-bold text-slate-900 mb-2">Manajemen Kurikulum</h2>
                <p class="text-sm text-slate-600 leading-relaxed">Pengelolaan data kelas, mata pelajaran, serta
                    pembagian jadwal pengajar secara terpusat.</p>
            </div>

            <div class="bg-white p-6 rounded-2xl border border-emerald-100 shadow-sm">
                <div class="text-xs font-bold text-emerald-600 uppercase tracking-wider mb-2">02. Presensi</div>
                <h2 class="text-lg font-bold text-slate-900 mb-2">Rekap Kehadiran</h2>
                <p class="text-sm text-slate-600 leading-relaxed">Pencatatan dan pemantauan tingkat kehadiran siswa
                    harian dengan akurat dan efisien.</p>
            </div>

            <div class="bg-white p-6 rounded-2xl border border-emerald-100 shadow-sm">
                <div class="text-xs font-bold text-emerald-600 uppercase tracking-wider mb-2">03. Evaluasi</div>
                <h2 class="text-lg font-bold text-slate-900 mb-2">Penilaian & Raport</h2>
                <p class="text-sm text-slate-600 leading-relaxed">Pengolahan nilai tugas, ujian, hingga generasi lembar
                    raport akademik siap cetak.</p>
            </div>
        </div>
    </main>

    <footer class="w-full max-w-7xl mx-auto px-6 py-8 border-t border-emerald-100 text-center text-xs text-slate-500">
        &copy; {{ date('Y') }} SMPIT Insan Mulia Wonosobo. Hak Cipta Dilindungi Undang-Undang.
    </footer>
</body>

</html>