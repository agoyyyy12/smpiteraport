<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - SIAKAD SMPIT Insan Mulia Wonosobo</title>
    @if (file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot')))
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    @else
    <script src="https://cdn.tailwindcss.com"></script>
    @endif
</head>

<body class="bg-emerald-50/40 font-sans antialiased flex items-center justify-center min-h-screen px-4">
    <div class="max-w-md w-full bg-white rounded-2xl shadow-sm border border-emerald-100 p-8">
        <div class="text-center mb-8">
            <img src="{{ asset('images/logo.webp') }}" alt="Logo SMPIT Insan Mulia"
                class="w-16 h-16 object-contain mx-auto mb-3">
            <h2 class="text-2xl font-extrabold text-slate-900 tracking-tight">SIAKAD</h2>
            <p class="text-sm text-emerald-700 font-semibold">SMPIT Insan Mulia Wonosobo</p>
        </div>

        @if($errors->any())
        <div class="mb-6 bg-rose-50 border border-rose-200 text-rose-700 px-4 py-3 rounded-xl text-sm">
            {{ $errors->first() }}
        </div>
        @endif

        <form action="{{ route('login') }}" method="POST" class="space-y-5">
            @csrf
            <div>
                <label class="block text-sm font-medium text-slate-700 mb-1">Email</label>
                <input type="email" name="email" value="{{ old('email') }}" required maxlength="255"
                    autocomplete="email" autofocus
                    class="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm">
            </div>
            <div>
                <div class="flex justify-between items-center mb-1">
                    <label class="block text-sm font-medium text-slate-700">Password</label>
                    <button type="button" onclick="openModal()"
                        class="text-xs font-semibold text-emerald-700 hover:text-emerald-800 hover:underline border-0 bg-transparent p-0 cursor-pointer">
                        Lupa Password?
                    </button>
                </div>
                <input type="password" name="password" required autocomplete="current-password"
                    class="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm">
            </div>
            <button type="submit"
                class="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-3 rounded-xl transition shadow-md">
                Masuk Sistem
            </button>
        </form>

        <div class="mt-8 pt-6 border-t border-slate-100 text-center">
            <a href="{{ url('/') }}" class="text-xs font-medium text-slate-500 hover:text-slate-700 transition">
                Kembali ke Halaman Utama
            </a>
        </div>
    </div>

    <div id="forgotPasswordModal"
        class="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4 hidden z-50">
        <div class="bg-white rounded-2xl max-w-sm w-full p-6 shadow-xl border border-emerald-100 text-center">
            <h3 class="text-lg font-bold text-slate-900 mb-2">Reset Password</h3>
            <p class="text-sm text-slate-600 leading-relaxed mb-6">
                Untuk alasan keamanan, pemulihan password akun SIAKAD dilakukan melalui Administrator Sekolah. Silakan
                hubungi bagian Tata Usaha atau Admin SIAKAD SMPIT Insan Mulia Wonosobo.
            </p>
            <button type="button" onclick="closeModal()"
                class="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-2.5 rounded-xl transition shadow">
                Mengerti
            </button>
        </div>
    </div>

    <script>
    function openModal() {
        document.getElementById('forgotPasswordModal').classList.remove('hidden');
    }

    function closeModal() {
        document.getElementById('forgotPasswordModal').classList.add('hidden');
    }
    </script>
</body>

</html>