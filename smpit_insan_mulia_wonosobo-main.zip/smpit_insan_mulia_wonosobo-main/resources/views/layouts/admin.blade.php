<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'SIAKAD - SMPIT Insan Mulia Wonosobo')</title>
    @if (file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot')))
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    @else
        <script src="https://cdn.tailwindcss.com"></script>
    @endif
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
</head>

<body class="bg-slate-100/70 font-sans antialiased text-slate-800 min-h-screen flex relative">
    <div id="sidebarBackdrop" onclick="toggleSidebar()"
        class="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-40 hidden md:hidden transition-opacity"></div>

    <aside id="sidebar"
        class="fixed md:static inset-y-0 left-0 w-64 bg-slate-900 text-slate-300 flex flex-col justify-between shrink-0 min-h-screen border-r border-slate-800 z-50 transform -translate-x-full md:translate-x-0 transition-transform duration-200 ease-in-out">
        <div>
            <div class="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/50">
                <div class="flex items-center space-x-3">
                    <img src="{{ asset('images/logo.webp') }}" alt="Logo SMPIT Insan Mulia"
                        class="w-9 h-9 object-contain bg-white rounded-lg p-1">
                    <div>
                        <h1 class="text-sm font-bold text-white tracking-tight leading-none">SIAKAD Panel</h1>
                        <span class="text-xs text-emerald-400 font-medium">SMPIT Insan Mulia</span>
                    </div>
                </div>
                <button type="button" onclick="toggleSidebar()"
                    class="md:hidden text-xs text-slate-400 hover:text-white font-bold p-1">
                    Tutup
                </button>
            </div>

            <nav class="p-4 space-y-6">
                <div>
                    <span
                        class="px-3 text-[11px] font-bold uppercase tracking-wider text-slate-500 block mb-2">Utama</span>
                    <a href="{{ route('home') }}"
                        class="flex items-center px-3 py-2.5 rounded-xl text-sm font-semibold {{ request()->routeIs('home') ? 'bg-emerald-600 text-white shadow-sm' : 'hover:bg-slate-800 hover:text-white transition' }}">
                        Dashboard
                    </a>
                </div>

                <div>
                    <span class="px-3 text-[11px] font-bold uppercase tracking-wider text-slate-500 block mb-2">Data
                        Master</span>
                    <div class="space-y-1">
                        <a href="{{ route('admin.academic-years.index') }}"
                            class="block px-3 py-2 rounded-xl text-sm font-medium {{ request()->routeIs('admin.academic-years.*') ? 'bg-emerald-600 text-white font-semibold' : 'hover:bg-slate-800 hover:text-white transition' }}">Tahun
                            Ajaran</a>
                        <a href="{{ route('admin.classrooms.index') }}"
                            class="block px-3 py-2 rounded-xl text-sm font-medium {{ request()->routeIs('admin.classrooms.*') ? 'bg-emerald-600 text-white font-semibold' : 'hover:bg-slate-800 hover:text-white transition' }}">Data
                            Kelas</a>
                        <a href="{{ route('admin.teachers.index') }}"
                            class="block px-3 py-2 rounded-xl text-sm font-medium {{ request()->routeIs('admin.teachers.*') ? 'bg-emerald-600 text-white font-semibold' : 'hover:bg-slate-800 hover:text-white transition' }}">Data
                            Guru</a>
                        <a href="{{ route('admin.students.index') }}"
                            class="block px-3 py-2 rounded-xl text-sm font-medium {{ request()->routeIs('admin.students.*') ? 'bg-emerald-600 text-white font-semibold' : 'hover:bg-slate-800 hover:text-white transition' }}">Data
                            Siswa</a>
                        <a href="{{ route('admin.subjects.index') }}"
                            class="block px-3 py-2 rounded-xl text-sm font-medium {{ request()->routeIs('admin.subjects.*') ? 'bg-emerald-600 text-white font-semibold' : 'hover:bg-slate-800 hover:text-white transition' }}">Kurikulum</a>
                    </div>
                </div>

                <div>
                    <span
                        class="px-3 text-[11px] font-bold uppercase tracking-wider text-slate-500 block mb-2">Pembelajaran
                        & Evaluasi</span>
                    <div class="space-y-1">
                        <a href="{{ route('admin.schedules.index') }}"
                            class="block px-3 py-2 rounded-xl text-sm font-medium {{ request()->routeIs('admin.schedules.*') ? 'bg-emerald-600 text-white font-semibold' : 'hover:bg-slate-800 hover:text-white transition' }}">Jadwal
                            Pelajaran</a>
                        <a href="{{ route('admin.attendances.index') }}"
                            class="block px-3 py-2 rounded-xl text-sm font-medium {{ request()->routeIs('admin.attendances.*') ? 'bg-emerald-600 text-white font-semibold' : 'hover:bg-slate-800 hover:text-white transition' }}">Absensi
                            Siswa</a>
                        <a href="{{ route('admin.kekhasan.index') }}"
                            class="block px-3 py-2 rounded-xl text-sm font-medium {{ request()->routeIs('admin.kekhasan.*') ? 'bg-emerald-600 text-white font-semibold' : 'hover:bg-slate-800 hover:text-white transition' }}">Penilaian
                            Nilai</a>
                        <a href="{{ route('admin.reports.index') }}"
                            class="block px-3 py-2 rounded-xl text-sm font-medium {{ request()->routeIs('admin.reports.*') ? 'bg-emerald-600 text-white font-semibold' : 'hover:bg-slate-800 hover:text-white transition' }}">Cetak
                            Raport</a>
                    </div>
                </div>
            </nav>
        </div>

        <div class="p-4 border-t border-slate-800 bg-slate-950/30">
            <div class="flex items-center justify-between">
                <div>
                    <span
                        class="block text-xs font-semibold text-white truncate max-w-[120px]">{{ auth()->user()->name ?? 'Administrator' }}</span>
                    <span class="block text-[11px] text-emerald-400 font-medium">Administrator</span>
                </div>
                <form action="{{ route('logout') }}" method="POST">
                    @csrf
                    <button type="submit"
                        class="text-xs bg-slate-800 hover:bg-rose-950 text-slate-300 hover:text-rose-200 px-3 py-1.5 rounded-lg border border-slate-700 transition font-semibold">
                        Keluar
                    </button>
                </form>
            </div>
        </div>
    </aside>

    <div class="flex-1 flex flex-col min-w-0 w-full">
        <div
            class="md:hidden bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between sticky top-0 z-30 shadow-sm">
            <button type="button" onclick="toggleSidebar()"
                class="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold px-3 py-2 rounded-xl text-xs border border-slate-200 transition">
                Menu Navigasi
            </button>
            <span
                class="px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold border border-emerald-200">
                SMPIT Insan Mulia
            </span>
        </div>

        <main class="p-6 md:p-10 flex-1">
            @yield('content')
        </main>

        <footer class="px-8 py-5 border-t border-slate-200/80 bg-white text-center text-xs text-slate-500">
            &copy; {{ date('Y') }} SMPIT Insan Mulia Wonosobo. Hak Cipta Dilindungi Undang-Undang.
        </footer>
    </div>

    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const backdrop = document.getElementById('sidebarBackdrop');

            sidebar.classList.toggle('-translate-x-full');
            backdrop.classList.toggle('hidden');
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            flatpickr(".timepicker-24", {
                enableTime: true,
                noCalendar: true,
                dateFormat: "H:i",
                time_24hr: true,
                minuteIncrement: 5
            });
        });
    </script>
</body>

</html>