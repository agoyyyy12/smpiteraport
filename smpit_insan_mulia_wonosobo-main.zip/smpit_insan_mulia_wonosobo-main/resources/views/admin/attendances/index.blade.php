@extends('layouts.admin')

@section('title', 'Rekap Absensi Siswa - SIAKAD SMPIT Insan Mulia')

@section('content')
<div class="max-w-7xl mx-auto">
    @if(session('success'))
    <div
        class="mb-6 bg-emerald-50 border border-emerald-200 text-emerald-700 px-4 py-3 rounded-xl text-sm shadow-sm flex items-center justify-between">
        <span>{{ session('success') }}</span>
    </div>
    @endif

    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div>
            <h2 class="text-xl font-bold text-slate-900">Rekap Kehadiran Siswa</h2>
            <p class="text-sm text-slate-500">Pantau dan kelola data kehadiran harian peserta didik.</p>
        </div>
        <a href="{{ route('admin.attendances.create') }}"
            class="bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold px-5 py-2.5 rounded-xl shadow-sm transition flex items-center gap-2">
            <span>+ Input Absensi Baru</span>
        </a>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-5 mb-6">
        <form method="GET" action="{{ route('admin.attendances.index') }}"
            class="grid grid-cols-1 sm:grid-cols-3 gap-4 items-end">
            <div>
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Pilih Kelas</label>
                <select name="kelas_id" required
                    class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500">
                    <option value="">-- Pilih Kelas --</option>
                    @foreach($kelasList as $kelas)
                    <option value="{{ $kelas->id }}" {{ $kelasId == $kelas->id ? 'selected' : '' }}>
                        {{ $kelas->nama }}</option>
                    @endforeach
                </select>
            </div>
            <div>
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Tanggal</label>
                <input type="date" name="tanggal" value="{{ $tanggal }}" required
                    class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500">
            </div>
            <div>
                <button type="submit"
                    class="w-full bg-emerald-800 hover:bg-emerald-900 text-white font-semibold py-2.5 rounded-xl transition text-sm">
                    Tampilkan Data
                </button>
            </div>
        </form>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-slate-200/80 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr
                        class="bg-slate-50/70 border-b border-slate-200 text-xs font-bold text-slate-500 uppercase tracking-wider">
                        <th class="px-6 py-4">NIS</th>
                        <th class="px-6 py-4">Nama Siswa</th>
                        <th class="px-6 py-4">Status Kehadiran</th>
                        <th class="px-6 py-4">Keterangan</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 text-sm text-slate-700">
                    @forelse($absensis as $item)
                    <tr class="hover:bg-slate-50/50 transition">
                        <td class="px-6 py-4 font-semibold text-slate-900">{{ $item->siswa->nis ?? '-' }}</td>
                        <td class="px-6 py-4 font-medium text-slate-800">{{ $item->siswa->user->name ?? '-' }}</td>
                        <td class="px-6 py-4">
                            @php
                            $badgeColor = match($item->status) {
                            'Hadir' => 'bg-emerald-50 text-emerald-700 border border-emerald-200',
                            'Izin' => 'bg-blue-50 text-blue-700 border border-blue-200',
                            'Sakit' => 'bg-amber-50 text-amber-700 border border-amber-200',
                            default => 'bg-rose-50 text-rose-700 border border-rose-200',
                            };
                            @endphp
                            <span class="px-3 py-1 text-xs font-bold rounded-full {{ $badgeColor }}">
                                {{ $item->status }}
                            </span>
                        </td>
                        <td class="px-6 py-4 text-slate-500">{{ $item->keterangan ?? '-' }}</td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="4" class="px-6 py-12 text-center text-slate-400 text-sm">
                            Belum ada data absensi untuk kelas dan tanggal tersebut.
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection