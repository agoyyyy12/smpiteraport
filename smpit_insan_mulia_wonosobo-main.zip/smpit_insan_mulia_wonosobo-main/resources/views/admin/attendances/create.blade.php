@extends('layouts.admin')

@section('title', 'Input Absensi Siswa - SIAKAD SMPIT Insan Mulia')

@section('content')
    <div class="max-w-5xl mx-auto">
        <div class="mb-6 flex items-center justify-between">
            <div>
                <h2 class="text-xl font-bold text-slate-900">Form Input Absensi Siswa</h2>
                <p class="text-sm text-slate-500">Pilih kelas dan tanggal terlebih dahulu untuk mengisi daftar hadir siswa.
                </p>
            </div>
            <a href="{{ route('admin.attendances.index') }}"
                class="text-xs bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold px-4 py-2 rounded-xl transition">
                &larr; Kembali
            </a>
        </div>

        <div class="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-6 mb-6">
            <form method="GET" action="{{ route('admin.attendances.create') }}"
                class="grid grid-cols-1 md:grid-cols-2 gap-4 items-end">
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Pilih Kelas</label>
                    <select name="kelas_id" onchange="this.form.submit()" required
                        class="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500">
                        <option value="">-- Pilih Kelas --</option>
                        @foreach($kelasList as $kelas)
                            <option value="{{ $kelas->id }}" {{ $kelasId == $kelas->id ? 'selected' : '' }}>
                                {{ $kelas->nama }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Tanggal</label>
                    <input type="date" name="tanggal" value="{{ $tanggal }}" onchange="this.form.submit()" required
                        class="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500">
                </div>
            </form>
        </div>

        @if($kelasId && count($siswas) > 0)
            <form action="{{ route('admin.attendances.store') }}" method="POST">
                @csrf
                <input type="hidden" name="kelas_id" value="{{ $kelasId }}">
                <input type="hidden" name="tanggal" value="{{ $tanggal }}">

                <div class="bg-white rounded-2xl shadow-sm border border-slate-200/80 overflow-hidden mb-6">
                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-collapse">
                            <thead>
                                <tr
                                    class="bg-slate-50/70 border-b border-slate-200 text-xs font-bold text-slate-500 uppercase tracking-wider">
                                    <th class="px-6 py-4">NIS</th>
                                    <th class="px-6 py-4">Nama Siswa</th>
                                    <th class="px-6 py-4">Status Kehadiran</th>
                                    <th class="px-6 py-4">Keterangan</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 text-sm text-slate-700">
                                @foreach($siswas as $siswa)
                                    <tr class="hover:bg-slate-50/50 transition">
                                        <td class="px-6 py-4 font-semibold text-slate-900">{{ $siswa->nis }}</td>
                                        <td class="px-6 py-4 font-medium text-slate-800">{{ $siswa->user->name }}</td>
                                        <td class="px-6 py-4">
                                            <select name="attendance[{{ $siswa->id }}][status]"
                                                class="px-3 py-2 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500">
                                                <option value="Hadir">Hadir</option>
                                                <option value="Izin">Izin</option>
                                                <option value="Sakit">Sakit</option>
                                                <option value="Alpa">Alpa</option>
                                            </select>
                                        </td>
                                        <td class="px-6 py-4">
                                            <input type="text" name="attendance[{{ $siswa->id }}][keterangan]"
                                                placeholder="Keterangan opsional..."
                                                class="w-full px-4 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500">
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>

                <button type="submit"
                    class="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-3 rounded-xl transition shadow-sm text-sm">
                    Simpan Data Absensi
                </button>
            </form>
        @elseif($kelasId)
            <div class="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-12 text-center text-slate-400 text-sm">
                Tidak ada siswa aktif di kelas ini.
            </div>
        @else
            <div class="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-12 text-center text-slate-400 text-sm">
                Silakan pilih kelas terlebih dahulu untuk mulai melakukan input absensi.
            </div>
        @endif
    </div>
@endsection