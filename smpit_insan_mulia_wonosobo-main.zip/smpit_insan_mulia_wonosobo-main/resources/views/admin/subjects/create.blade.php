@extends('layouts.admin')

@section('title', 'Tambah Mata Pelajaran - SIAKAD SMPIT Insan Mulia')

@section('content')
<div class="max-w-2xl mx-auto">
    <div class="mb-6 flex items-center justify-between">
        <h2 class="text-xl font-bold text-slate-900">Tambah Mata Pelajaran Baru</h2>
        <a href="{{ route('admin.subjects.index') }}"
            class="text-xs bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold px-4 py-2 rounded-xl transition">
            &larr; Kembali
        </a>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-8">
        <form action="{{ route('admin.subjects.store') }}" method="POST" class="space-y-5">
            @csrf

            <div>
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Metode Kode
                    Mapel</label>
                <div class="flex gap-4">
                    <label class="flex items-center gap-2 cursor-pointer text-sm">
                        <input type="radio" name="generate_mode" value="auto" checked onchange="toggleKodeInput()">
                        <span>Generate Otomatis oleh Sistem</span>
                    </label>
                    <label class="flex items-center gap-2 cursor-pointer text-sm">
                        <input type="radio" name="generate_mode" value="manual" onchange="toggleKodeInput()">
                        <span>Input Manual</span>
                    </label>
                </div>
            </div>

            <div id="kode-input-container" class="hidden">
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Kode Mapel
                    Manual</label>
                <input type="text" name="kode" id="kode" value="{{ old('kode') }}" placeholder="Contoh: PAI, MTK, IPA"
                    class="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 uppercase">
                @error('kode')
                <span class="text-xs text-rose-500 mt-1 block">{{ $message }}</span>
                @enderror
            </div>

            <div>
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Nama Mata
                    Pelajaran</label>
                <input type="text" name="nama" value="{{ old('nama') }}" placeholder="Contoh: Matematika" required
                    class="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500">
                @error('nama')
                <span class="text-xs text-rose-500 mt-1 block">{{ $message }}</span>
                @enderror
            </div>

            <div>
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Kelompok</label>
                <select name="kelompok" required
                    class="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500">
                    <option value="">-- Pilih Kelompok --</option>
                    <option value="A" {{ old('kelompok') == 'A' ? 'selected' : '' }}>Kelompok A (Wajib)</option>
                    <option value="B" {{ old('kelompok') == 'B' ? 'selected' : '' }}>Kelompok B (Umum/Kewilayahan)
                    </option>
                    <option value="Mulok" {{ old('kelompok') == 'Mulok' ? 'selected' : '' }}>Mulok (Muatan Lokal)
                    </option>
                    <option value="Kekhasan" {{ old('kelompok') == 'Kekhasan' ? 'selected' : '' }}>Kekhasan</option>
                </select>
                @error('kelompok')
                <span class="text-xs text-rose-500 mt-1 block">{{ $message }}</span>
                @enderror
            </div>

            <button type="submit"
                class="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-3 rounded-xl transition shadow-sm text-sm mt-4">
                Simpan Mata Pelajaran
            </button>
        </form>
    </div>
</div>

<script>
function toggleKodeInput() {
    const mode = document.querySelector('input[name="generate_mode"]:checked').value;
    const container = document.getElementById('kode-input-container');
    const inputKode = document.getElementById('kode');

    if (mode === 'manual') {
        container.classList.remove('hidden');
        inputKode.setAttribute('required', 'required');
    } else {
        container.classList.add('hidden');
        inputKode.removeAttribute('required');
        inputKode.value = '';
    }
}
</script>
@endsection