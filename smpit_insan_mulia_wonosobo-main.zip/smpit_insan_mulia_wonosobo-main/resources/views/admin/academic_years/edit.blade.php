@extends('layouts.admin')

@section('title', 'Edit Tahun Ajaran - SIAKAD SMPIT Insan Mulia')

@section('content')
<div class="max-w-xl mx-auto">
    <div class="mb-6 flex items-center justify-between">
        <h2 class="text-xl font-bold text-slate-900">Edit Tahun Ajaran</h2>
        <a href="{{ route('admin.academic-years.index') }}"
            class="text-xs bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold px-4 py-2 rounded-xl transition">
            &larr; Kembali
        </a>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-8">
        <form action="{{ route('admin.academic-years.update', $academicYear->id) }}" method="POST" class="space-y-5">
            @csrf
            @method('PUT')

            <div>
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Nama Tahun
                    Ajaran</label>
                <input type="text" name="nama" value="{{ old('nama', $academicYear->nama) }}" required
                    class="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500">
                @error('nama')
                <span class="text-xs text-rose-500 mt-1 block">{{ $message }}</span>
                @enderror
            </div>

            <div>
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Semester</label>
                <select name="semester" required
                    class="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500">
                    <option value="Ganjil" {{ old('semester', $academicYear->semester) == 'Ganjil' ? 'selected' : '' }}>
                        Ganjil</option>
                    <option value="Genap" {{ old('semester', $academicYear->semester) == 'Genap' ? 'selected' : '' }}>
                        Genap</option>
                </select>
                @error('semester')
                <span class="text-xs text-rose-500 mt-1 block">{{ $message }}</span>
                @enderror
            </div>

            <div class="flex items-center space-x-3 pt-2 bg-slate-50 p-4 rounded-xl border border-slate-100">
                <input type="checkbox" name="is_aktif" value="1" id="is_aktif"
                    {{ old('is_aktif', $academicYear->is_aktif) ? 'checked' : '' }}
                    class="w-4 h-4 text-emerald-600 border-slate-300 rounded focus:ring-emerald-500">
                <label for="is_aktif" class="text-sm font-semibold text-slate-700 cursor-pointer">Jadikan sebagai Tahun
                    Ajaran Aktif</label>
            </div>

            <button type="submit"
                class="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-3 rounded-xl transition shadow-sm text-sm mt-4">
                Perbarui Tahun Ajaran
            </button>
        </form>
    </div>
</div>
@endsection