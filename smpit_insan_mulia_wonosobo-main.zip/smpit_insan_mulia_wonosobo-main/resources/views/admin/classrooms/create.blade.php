@extends('layouts.admin')

@section('title', 'Tambah Kelas - SIAKAD SMPIT Insan Mulia')

@section('content')
<div class="max-w-xl mx-auto">
    <div class="mb-6 flex items-center justify-between">
        <h2 class="text-xl font-bold text-slate-900">Tambah Kelas Baru</h2>
        <a href="{{ route('admin.classrooms.index') }}"
            class="text-xs bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold px-4 py-2 rounded-xl transition">
            &larr; Kembali
        </a>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-8">
        <form action="{{ route('admin.classrooms.store') }}" method="POST" class="space-y-5">
            @csrf
            <div>
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Nama Kelas</label>
                <select name="nama" id="selectNamaKelas" required onchange="toggleManualInput(this.value)"
                    class="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500">
                    <option value="">-- Pilih Nama Kelas --</option>
                    @foreach($existingClasses as $className)
                    <option value="{{ $className }}"
                        {{ (old('nama') == $className && old('nama') != 'MANUAL') ? 'selected' : '' }}>
                        {{ $className }}
                    </option>
                    @endforeach
                    <option value="MANUAL" {{ old('nama') == 'MANUAL' ? 'selected' : '' }}>+ Ketik Nama Kelas Baru
                        (Lainnya)...</option>
                </select>
                @error('nama')
                <span class="text-xs text-rose-500 mt-1 block">{{ $message }}</span>
                @enderror
            </div>

            <div id="wrapperManualNama" class="{{ old('nama') == 'MANUAL' ? '' : 'hidden' }}">
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Ketik Nama Kelas
                    Baru</label>
                <input type="text" name="manual_nama" id="inputManualNama" value="{{ old('manual_nama') }}"
                    placeholder="Contoh: IX Umar Bin Khattab"
                    class="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500">
                @error('manual_nama')
                <span class="text-xs text-rose-500 mt-1 block">{{ $message }}</span>
                @enderror
            </div>

            <div>
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Tingkat</label>
                <select name="tingkat" required
                    class="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500">
                    <option value="">-- Pilih Tingkat Kelas --</option>
                    <option value="7" {{ old('tingkat') == 7 ? 'selected' : '' }}>Kelas 7</option>
                    <option value="8" {{ old('tingkat') == 8 ? 'selected' : '' }}>Kelas 8</option>
                    <option value="9" {{ old('tingkat') == 9 ? 'selected' : '' }}>Kelas 9</option>
                </select>
                @error('tingkat')
                <span class="text-xs text-rose-500 mt-1 block">{{ $message }}</span>
                @enderror
            </div>

            <div>
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Wali Kelas</label>
                <select name="wali_kelas_id"
                    class="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500">
                    <option value="">-- Pilih Wali Kelas --</option>
                    @foreach($gurus as $guru)
                    <option value="{{ $guru->id }}" {{ old('wali_kelas_id') == $guru->id ? 'selected' : '' }}>
                        {{ $guru->user->name ?? '-' }}
                    </option>
                    @endforeach
                </select>
                @error('wali_kelas_id')
                <span class="text-xs text-rose-500 mt-1 block">{{ $message }}</span>
                @enderror
            </div>

            <button type="submit"
                class="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-3 rounded-xl transition shadow-sm text-sm mt-4">
                Simpan Data Kelas
            </button>
        </form>
    </div>
</div>

<script>
function toggleManualInput(val) {
    const wrapper = document.getElementById('wrapperManualNama');
    const inputField = document.getElementById('inputManualNama');
    if (val === 'MANUAL') {
        wrapper.classList.remove('hidden');
        inputField.setAttribute('required', 'required');
    } else {
        wrapper.classList.add('hidden');
        inputField.removeAttribute('required');
        inputField.value = '';
    }
}
</script>
@endsection