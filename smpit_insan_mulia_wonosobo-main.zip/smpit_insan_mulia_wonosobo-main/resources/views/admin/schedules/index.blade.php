@extends('layouts.admin')

@section('title', 'Manajemen Jadwal Pelajaran - SIAKAD SMPIT Insan Mulia')

@section('content')
<div class="max-w-7xl mx-auto">
    @if(session('success'))
    <div
        class="mb-6 bg-emerald-50 border border-emerald-200 text-emerald-700 px-4 py-3 rounded-xl text-sm shadow-sm flex items-center justify-between">
        <span>{{ session('success') }}</span>
    </div>
    @endif

    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div>
            <h2 class="text-xl font-bold text-slate-900">Daftar Jadwal Pelajaran</h2>
            <p class="text-sm text-slate-500">Kelola jadwal pelajaran, kode jadwal, kelas, serta guru pengampu di
                sekolah.</p>
        </div>
        <a href="{{ route('admin.schedules.create') }}"
            class="bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold px-5 py-2.5 rounded-xl shadow-sm transition flex items-center gap-2">
            <span>+ Tambah Jadwal Baru</span>
        </a>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-5 mb-6">
        <form method="GET" action="{{ route('admin.schedules.index') }}" class="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
                <input type="text" name="search" value="{{ request('search') }}"
                    placeholder="Cari kode atau nama mapel/guru..."
                    class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500">
            </div>
            <div>
                <select name="hari"
                    class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500">
                    <option value="">-- Semua Hari --</option>
                    @foreach(['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'] as $h)
                    <option value="{{ $h }}" {{ request('hari') == $h ? 'selected' : '' }}>{{ $h }}</option>
                    @endforeach
                </select>
            </div>
            <div class="flex gap-2">
                <button type="submit"
                    class="flex-1 bg-emerald-800 hover:bg-emerald-900 text-white text-sm font-semibold py-2.5 rounded-xl transition">
                    Filter Data
                </button>
                @if(request('search') || request('hari'))
                <a href="{{ route('admin.schedules.index') }}"
                    class="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 text-sm font-semibold rounded-xl transition flex items-center justify-center">
                    Reset
                </a>
                @endif
            </div>
        </form>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-slate-200/80 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr
                        class="bg-slate-50/70 border-b border-slate-200 text-xs font-bold text-slate-500 uppercase tracking-wider">
                        <th class="px-6 py-4">Kode</th>
                        <th class="px-6 py-4">Hari & Jam</th>
                        <th class="px-6 py-4">Kelas</th>
                        <th class="px-6 py-4">Mata Pelajaran</th>
                        <th class="px-6 py-4">Guru Pengampu</th>
                        <th class="px-6 py-4 text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 text-sm text-slate-700">
                    @forelse($schedules as $item)
                    <tr class="hover:bg-slate-50/50 transition">
                        <td class="px-6 py-4">
                            <span
                                class="inline-block max-w-[120px] truncate px-2.5 py-1 text-xs font-mono font-semibold bg-slate-100 text-slate-800 rounded-md border border-slate-200"
                                title="{{ $item->kode }}">
                                {{ $item->kode }}
                            </span>
                        </td>

                        <td class="px-6 py-4">
                            <div class="flex items-center gap-2 mb-1">
                                <span
                                    class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-100">
                                    {{ $item->hari }}
                                </span>
                            </div>
                            <div class="text-xs text-slate-500 flex items-center gap-1 font-medium">
                                <svg class="w-3.5 h-3.5 text-slate-400" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                {{ substr($item->jam_mulai, 0, 5) }} - {{ substr($item->jam_selesai, 0, 5) }}
                            </div>
                        </td>

                        <td class="px-6 py-4">
                            <span class="font-semibold text-slate-800 bg-slate-100/80 px-3 py-1 rounded-lg text-xs">
                                {{ $item->kelas->nama ?? '-' }}
                            </span>
                        </td>

                        <td class="px-6 py-4">
                            <div class="font-semibold text-slate-900 text-xs">{{ $item->mataPelajaran->nama ?? '-' }}
                            </div>
        </div>
        </td>

        <td class="px-6 py-4">
            <div class="flex items-center gap-2">
                <span class="inline-block max-w-[150px] truncate font-medium text-slate-700 text-xs"
                    title="{{ $item->guru->user->name ?? '-' }}">{{ $item->guru->user->name ?? '-' }}</span>
            </div>
        </td>

        <td class="px-6 py-4 text-center space-x-2">
            <a href="{{ route('admin.schedules.edit', $item->id) }}"
                class="text-emerald-600 hover:text-emerald-700 font-semibold text-xs bg-emerald-50 hover:bg-emerald-100 px-3 py-1.5 rounded-lg transition inline-block">Edit</a>

            <button type="button"
                onclick="openDeleteModal('{{ route('admin.schedules.destroy', $item->id) }}', '{{$item->kode }}')"
                class="text-rose-600 hover:text-rose-700 font-semibold text-xs bg-rose-50 hover:bg-rose-100 px-3 py-1.5 rounded-lg transition">
                Hapus
            </button>
        </td>
        </tr>
        @empty
        <tr>
            <td colspan="6" class="px-6 py-12 text-center text-slate-400 text-sm">
                Tidak ada data jadwal pelajaran yang ditemukan.
            </td>
        </tr>
        @endforelse
        </tbody>
        </table>
    </div>
</div>
</div>

<div id="deleteModal"
    class="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm hidden opacity-0 transition-opacity duration-300">
    <div class="bg-white rounded-2xl shadow-xl border border-slate-100 max-w-md w-full mx-4 p-6 transform scale-95 transition-transform duration-300"
        id="modalContainer">
        <div class="flex items-center justify-center w-12 h-12 mx-auto mb-4 bg-rose-50 text-rose-600 rounded-full">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z">
                </path>
            </svg>
        </div>
        <h3 class="text-lg font-bold text-slate-900 text-center mb-2">Konfirmasi Hapus Data</h3>
        <p class="text-sm text-slate-500 text-center mb-6" id="deleteMessage">
            Apakah Anda yakin ingin menghapus data ini? Tindakan ini tidak dapat dibatalkan.
        </p>
        <div class="flex gap-3">
            <button type="button" onclick="closeDeleteModal()"
                class="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold py-2.5 rounded-xl transition text-sm">
                Batal
            </button>
            <form id="deleteForm" method="POST" class="flex-1">
                @csrf
                @method('DELETE')
                <button type="submit"
                    class="w-full bg-rose-600 hover:bg-rose-700 text-white font-semibold py-2.5 rounded-xl transition text-sm shadow-sm">
                    Ya, Hapus
                </button>
            </form>
        </div>
    </div>
</div>

<script>
function openDeleteModal(deleteUrl, itemCode) {
    const modal = document.getElementById('deleteModal');
    const modalContainer = document.getElementById('modalContainer');
    const deleteForm = document.getElementById('deleteForm');
    const deleteMessage = document.getElementById('deleteMessage');

    deleteForm.action = deleteUrl;
    deleteMessage.innerHTML =
        `Apakah Anda yakin ingin menghapus jadwal dengan kode <span class="font-semibold text-slate-800">"${itemCode}"</span>? Tindakan ini tidak dapat dibatalkan.`;

    modal.classList.remove('hidden');
    setTimeout(() => {
        modal.classList.remove('opacity-0');
        modalContainer.classList.remove('scale-95');
        modalContainer.classList.add('scale-100');
    }, 10);
}

function closeDeleteModal() {
    const modal = document.getElementById('deleteModal');
    const modalContainer = document.getElementById('modalContainer');

    modal.classList.add('opacity-0');
    modalContainer.classList.remove('scale-100');
    modalContainer.classList.add('scale-95');
    setTimeout(() => {
        modal.classList.add('hidden');
    }, 300);
}
</script>
@endsection