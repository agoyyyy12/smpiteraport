@extends('layouts.admin')

@section('title', 'Tambah Jadwal Pelajaran - SIAKAD SMPIT Insan Mulia')

@section('content')
<div class="max-w-2xl mx-auto">
    <div class="mb-6 flex items-center justify-between">
        <h2 class="text-xl font-bold text-slate-900">Tambah Jadwal Pelajaran Baru</h2>
        <a href="{{ route('admin.schedules.index') }}"
            class="text-xs bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold px-4 py-2 rounded-xl transition">
            &larr; Kembali
        </a>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-8">
        <form action="{{ route('admin.schedules.store') }}" method="POST" class="space-y-5">
            @csrf

            <div>
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Metode Kode
                    Jadwal</label>
                <div class="flex gap-6">
                    <label class="flex items-center gap-2 cursor-pointer text-sm">
                        <input type="radio" name="generate_mode" value="auto" checked onchange="toggleKodeInput()">
                        <span>Generate Otomatis Terstruktur</span>
                    </label>
                    <label class="flex items-center gap-2 cursor-pointer text-sm">
                        <input type="radio" name="generate_mode" value="manual" onchange="toggleKodeInput()">
                        <span>Input Manual</span>
                    </label>
                </div>
            </div>

            <div id="kode-input-container" class="hidden">
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Kode Jadwal
                    Manual</label>
                <input type="text" name="kode" id="kode" value="{{ old('kode') }}" placeholder="Contoh: JDW-9A-01"
                    class="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 uppercase">
                @error('kode')
                <span class="text-xs text-rose-500 mt-1 block">{{ $message }}</span>
                @enderror
            </div>

            <div>
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Tahun Ajaran</label>
                <select name="tahun_ajaran_id" required
                    class="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500">
                    @foreach($tahunAjarans as $ta)
                    <option value="{{ $ta->id }}" {{ $ta->is_aktif ? 'selected' : '' }}>{{ $ta->nama }} - Semester
                        {{ $ta->semester }}
                    </option>
                    @endforeach
                </select>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Kelas</label>
                    <select name="kelas_id" required
                        class="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500">
                        <option value="">-- Pilih Kelas --</option>
                        @foreach($kelasList as $kelas)
                        <option value="{{ $kelas->id }}">{{ $kelas->nama }}</option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Hari</label>
                    <select name="hari" required
                        class="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500">
                        <option value="">-- Pilih Hari --</option>
                        <option value="Senin">Senin</option>
                        <option value="Selasa">Selasa</option>
                        <option value="Rabu">Rabu</option>
                        <option value="Kamis">Kamis</option>
                        <option value="Jumat">Jumat</option>
                        <option value="Sabtu">Sabtu</option>
                    </select>
                </div>
            </div>

            <div>
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Mata
                    Pelajaran</label>
                <select name="mata_pelajaran_id" required
                    class="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500">
                    <option value="">-- Pilih Mata Pelajaran --</option>
                    @foreach($subjects as $subject)
                    <option value="{{ $subject->id }}">{{ $subject->nama }} ({{ $subject->kode }})</option>
                    @endforeach
                </select>
            </div>

            <div>
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Guru
                    Pengampu</label>
                <select name="guru_id" required
                    class="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500">
                    <option value="">-- Pilih Guru --</option>
                    @foreach($teachers as $teacher)
                    <option value="{{ $teacher->id }}">{{ $teacher->user->name ?? '-' }}</option>
                    @endforeach
                </select>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Jam
                        Mulai</label>
                    <input type="text" name="jam_mulai" value="{{ old('jam_mulai', $schedule->jam_mulai ?? '') }}"
                        placeholder="Contoh: 07:00" required
                        class="timepicker-24 w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 bg-white">
                </div>
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Jam
                        Selesai</label>
                    <input type="text" name="jam_selesai" value="{{ old('jam_selesai', $schedule->jam_selesai ?? '') }}"
                        placeholder="Contoh: 08:30" required
                        class="timepicker-24 w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 bg-white">
                </div>
            </div>

            <button type="submit"
                class="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-3 rounded-xl transition shadow-sm text-sm mt-4">
                Simpan Jadwal Pelajaran
            </button>
        </form>
    </div>
</div>

<script>
function toggleKodeInput() {
    const mode = document.querySelector('input[name="generate_mode"]:checked').value;
    const container = document.getElementById('kode-input-container');
    const inputKode = document.getElementById('kode');

    if (mode === 'manual') {
        container.classList.remove('hidden');
        inputKode.setAttribute('required', 'required');
    } else {
        container.classList.add('hidden');
        inputKode.removeAttribute('required');
        inputKode.value = '';
    }
}
</script>
@endsection