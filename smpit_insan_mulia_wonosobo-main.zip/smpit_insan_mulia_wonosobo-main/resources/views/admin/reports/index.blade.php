@extends('layouts.admin')

@section('title', 'Cetak Raport Peserta Didik - SIAKAD SMPIT Insan Mulia')

@section('content')
<div class="max-w-7xl mx-auto">
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div>
            <h2 class="text-xl font-bold text-slate-900">Cetak Raport Peserta Didik</h2>
            <p class="text-sm text-slate-500">Pilih kelas untuk melihat dan mencetak dokumen hasil belajar serta
                kekhasan siswa.</p>
        </div>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-5 mb-6">
        <form method="GET" action="{{ route('admin.reports.index') }}" class="flex items-center gap-4">
            <div class="w-full sm:w-1/3">
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Pilih Kelas</label>
                <select name="kelas_id" onchange="this.form.submit()" required
                    class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500">
                    <option value="">-- Pilih Kelas --</option>
                    @foreach($kelasList as $kelas)
                    <option value="{{ $kelas->id }}" {{ $kelasId == $kelas->id ? 'selected' : '' }}>
                        {{ $kelas->nama }}
                    </option>
                    @endforeach
                </select>
            </div>
        </form>
    </div>

    @if($kelasId && count($siswas) > 0)
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200/80 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr
                        class="bg-slate-50/70 border-b border-slate-200 text-xs font-bold text-slate-500 uppercase tracking-wider">
                        <th class="px-6 py-4">NIS</th>
                        <th class="px-6 py-4">NISN</th>
                        <th class="px-6 py-4">Nama Siswa</th>
                        <th class="px-6 py-4 text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 text-sm text-slate-700">
                    @foreach($siswas as $siswaItem)
                    <tr class="hover:bg-slate-50/50 transition">
                        <td class="px-6 py-4 font-semibold text-slate-900">{{ $siswaItem->nis }}</td>
                        <td class="px-6 py-4 text-slate-500">{{ $siswaItem->nisn ?? '-' }}</td>
                        <td class="px-6 py-4 font-medium text-slate-800">{{ $siswaItem->user->name }}</td>
                        <td class="px-6 py-4 text-center flex justify-center gap-2">
                            <a href="{{ route('admin.reports.show', $siswaItem->id) }}"
                                class="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold px-3 py-2 rounded-xl transition inline-flex items-center gap-1">
                                Lihat Raport
                            </a>
                            <button type="button"
                                onclick="cetakLangsung('{{ route('admin.reports.show', $siswaItem->id) }}?print=true')"
                                class="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold px-3.5 py-2 rounded-xl transition shadow-sm inline-flex items-center gap-1">
                                Cetak Langsung
                            </button>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
    @elseif($kelasId)
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-12 text-center text-slate-400 text-sm">
        Tidak ada siswa aktif di kelas ini.
    </div>
    @else
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-12 text-center text-slate-400 text-sm">
        Silakan pilih kelas terlebih dahulu untuk melihat daftar siswa.
    </div>
    @endif
</div>

<iframe id="printIframe" class="hidden" style="display:none; width:0; height:0; border:0;"></iframe>

<script>
function cetakLangsung(url) {
    const iframe = document.getElementById('printIframe');
    iframe.src = url;
    iframe.onload = function() {
        setTimeout(function() {
            iframe.contentWindow.focus();
            iframe.contentWindow.print();
        }, 300);
    };
}
</script>
@endsection