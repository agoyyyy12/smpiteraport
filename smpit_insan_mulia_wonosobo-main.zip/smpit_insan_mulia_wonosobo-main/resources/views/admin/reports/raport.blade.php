@extends('layouts.admin')

@section('title', 'Laporan Pencapaian Peserta Didik - ' . $siswa->user->name)

@section('content')
    <div class="max-w-4xl mx-auto">
        <div class="mb-6 flex justify-between items-center no-print">
            <a href="{{ route('admin.reports.index', ['kelas_id' => $siswa->kelas_id]) }}"
                class="text-xs bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold px-4 py-2.5 rounded-xl transition flex items-center gap-1">
                &larr; Kembali ke Daftar Raport
            </a>
        </div>

        <table class="kop-table">
            <tr>
                <td class="kop-logo-jsit">
                    <img src="{{ asset('images/logo.webp') }}" alt="Logo JSIT">
                </td>
                <td class="kop-text">
                    LAPORAN PENCAPAIAN PESERTA DIDIK<br>
                    KEKHASAN {{ strtoupper($siswa->kelas->guru->sekolah->nama ?? 'SMPIT INSAN MULIA WONOSOBO') }}
                </td>
                <td class="kop-logo-smpit">
                    <img src="{{ asset('images/logo.webp') }}" onerror="this.onerror=null; this.src='https://placehold.co';"
                        alt="Logo Sekolah">
                </td>
            </tr>
        </table>

        <table class="table-info">
            <tr>
                <td width="16%">Nama Siswa</td>
                <td width="42%">: {{ $siswa->user->name }}</td>
                <td width="14%">Kelas</td>
                <td>: {{ $siswa->kelas->nama ?? '-' }}</td>
            </tr>
            <tr>
                <td>Nomor Induk</td>
                <td>: {{ $siswa->nis }}</td>
                <td>Semester</td>
                <td>: {{ $tahunAktif->semester ?? '-' }}</td>
            </tr>
            <tr>
                <td>Nama Sekolah</td>
                <td>: {{ $siswa->kelas->guru->sekolah->nama ?? 'SMPIT Insan Mulia Wonosobo' }}</td>
                <td>Tahun Ajaran</td>
                <td>: {{ $tahunAktif->nama ?? '-' }}</td>
            </tr>
            <tr>
                <td>Alamat Sekolah</td>
                <td colspan="3">: Jalan Kyai Walik, Jlegong, Pagerkukuh, Wonosobo, Jawa Tengah
                </td>
            </tr>
        </table>

        <div class="section-title">TAHFIDZUL QURAN</div>
        <table class="table-nilai">
            <thead>
                <tr>
                    <th width="12%">NO SURAT</th>
                    <th width="33%">NAMA SURAT</th>
                    <th width="15%">PREDIKAT</th>
                    <th width="40%">DESKRIPSI</th>
                </tr>
            </thead>
            <tbody>
                @if($nilaiKekhasan && ($nilaiKekhasan->tahfidz_no_surat || $nilaiKekhasan->tahfidz_nama_surat))
                    <tr>
                        <td align="center" style="font-weight: 500;">{{ $nilaiKekhasan->tahfidz_no_surat ?? '-' }}</td>
                        <td>{{ $nilaiKekhasan->tahfidz_nama_surat ?? '-' }}</td>
                        <td align="center" style="font-weight: bold;">{{ $nilaiKekhasan->tahfidz_predikat ?? '-' }}</td>
                        <td>{{ $nilaiKekhasan->tahfidz_deskripsi ?? '-' }}</td>
                    </tr>
                @else
                    <tr>
                        <td colspan="4" align="center" style="color: #6b7280; font-style: italic;">Belum ada data Tahfidzul
                            Quran.</td>
                    </tr>
                @endif
            </tbody>
        </table>

        <div class="section-title">QIROATY</div>
        <table class="table-nilai">
            <thead>
                <tr>
                    <th width="25%">JILID / CAPAIAN</th>
                    <th width="15%">PREDIKAT</th>
                    <th width="60%">DESKRIPSI</th>
                </tr>
            </thead>
            <tbody>
                @if($nilaiKekhasan && (!empty($nilaiKekhasan->qiroaty_jilid) || !empty($nilaiKekhasan->qiroaty_deskripsi)))
                    <tr>
                        <td align="center" style="font-weight: 500;">{{ $nilaiKekhasan->qiroaty_jilid ?? '-' }}</td>
                        <td align="center" style="font-weight: bold;">{{ $nilaiKekhasan->qiroaty_predikat ?? '-' }}</td>
                        <td>{{ $nilaiKekhasan->qiroaty_deskripsi ?? '-' }}</td>
                    </tr>
                @else
                    <tr>
                        <td colspan="3" align="center" style="color: #6b7280; font-style: italic;">Belum ada data Qiroaty.</td>
                    </tr>
                @endif
            </tbody>
        </table>

        <div class="section-title">BINA PRIBADI ISLAMI (BPI)</div>
        <table class="table-nilai">
            <thead>
                <tr>
                    <th width="8%">NO.</th>
                    <th width="32%">KRITERIA KARAKTER</th>
                    <th width="15%">PREDIKAT</th>
                    <th width="45%">DESKRIPSI</th>
                </tr>
            </thead>
            <tbody>
                @if($nilaiKekhasan && $nilaiKekhasan->bpi_kriteria)
                    <tr>
                        <td align="center">1.</td>
                        <td style="font-weight: 500;">{{ $nilaiKekhasan->bpi_kriteria }}</td>
                        <td align="center" style="font-weight: bold;">{{ $nilaiKekhasan->bpi_predikat ?? '-' }}</td>
                        <td>{{ $nilaiKekhasan->bpi_deskripsi ?? '-' }}</td>
                    </tr>
                @else
                    <tr>
                        <td colspan="4" align="center" style="color: #6b7280; font-style: italic;">Belum ada data BPI.</td>
                    </tr>
                @endif
            </tbody>
        </table>

        <table class="ttd-table">
            <tr>
                <td>
                    Orang tua / Wali<br><br><br><br><br>
                    __________________
                </td>
                <td>
                    Wonosobo,
                    {{ $nilaiKekhasan->tanggal_cetak ? \Carbon\Carbon::parse($nilaiKekhasan->tanggal_cetak)->isoFormat('D MMMM Y') : \Carbon\Carbon::now()->isoFormat('D MMMM Y') }}<br>
                    Wali Kelas<br><br><br><br><br>
                    <span class="ttd-nama">{{ $siswa->kelas->waliKelas->user->name ?? '-' }}</span>
                </td>
            </tr>
            <tr>
                <td colspan="2" style="text-align: center; padding-top: 15px;">
                    Mengetahui<br>
                    Kepala Sekolah<br><br><br><br><br>
                    <span
                        class="ttd-nama">{{ $siswa->kelas->guru->sekolah->kepalaSekolah->user->name ?? $siswa->kelas->waliKelas->guru->sekolah->nama_kepsek ?? 'Liza Pettiana Sari, S.Kom., M.Pd.' }}</span>
                </td>
            </tr>
        </table>
        <style>
            body {
                font-family: Arial, Helvetica, sans-serif;
                font-size: 11px;
                color: #000;
                background: #fff !important;
                margin: 0;
                padding: 0;
                line-height: 1.4;
            }

            /* Kop Surat Resmi Microsoft Word Style */
            .kop-table {
                width: 100%;
                border-collapse: collapse;
                border-bottom: 3px double #000;
                margin-bottom: 20px;
            }

            .kop-logo-jsit {
                width: 70px;
                text-align: left;
                vertical-align: middle;
                padding-bottom: 10px;
            }

            .kop-text {
                text-align: center;
                vertical-align: middle;
                font-weight: bold;
                font-size: 14px;
                text-transform: uppercase;
                padding-bottom: 10px;
                line-height: 1.3;
            }

            .kop-logo-smpit {
                width: 70px;
                text-align: right;
                vertical-align: middle;
                padding-bottom: 10px;
            }

            .kop-logo-jsit img,
            .kop-logo-smpit img {
                max-height: 65px;
                max-width: 65px;
                object-fit: contain;
            }

            /* Tabel Informasi Identitas Siswa */
            .table-info {
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 25px;
            }

            .table-info td {
                padding: 3px 0;
                vertical-align: top;
            }

            /* Judul Menu Utama Raport Kekhasan */
            .section-title {
                font-weight: bold;
                margin-top: 18px;
                margin-bottom: 6px;
                font-size: 11px;
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }

            /* Tabel Komponen Nilai */
            .table-nilai {
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 20px;
            }

            .table-nilai th,
            .table-nilai td {
                border: 1px solid #000;
                padding: 7px 8px;
                vertical-align: top;
            }

            .table-nilai th {
                background-color: #f3f4f6 !important;
                font-weight: bold;
                text-align: center;
                text-transform: uppercase;
            }

            /* Layout Block Tanda Tangan */
            .ttd-table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 35px;
            }

            .ttd-table td {
                text-align: center;
                vertical-align: top;
                width: 50%;
                padding-bottom: 15px;
            }

            .ttd-nama {
                font-weight: bold;
                text-decoration: underline;
            }

            /* CSS Engine Browser Print */
            @media print {
                body {
                    background: white !important;
                    margin: 0 !important;
                    padding: 0 !important;
                    -webkit-print-color-adjust: exact !important;
                    print-color-adjust: exact !important;
                }

                @page {
                    size: A4 portrait;
                    margin: 1.5cm 1.5cm 1.5cm 1.5cm;
                }

                .table-nilai th {
                    background-color: #f3f4f6 !important;
                }
            }
        </style>
@endsection