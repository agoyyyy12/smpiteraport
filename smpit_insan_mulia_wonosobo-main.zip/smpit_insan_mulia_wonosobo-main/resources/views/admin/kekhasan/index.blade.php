@extends('layouts.admin')

@section('title', 'Rekap Nilai Kekhasan - SIAKAD SMPIT Insan Mulia')

@section('content')
<div class="max-w-7xl mx-auto">
    @if(session('success'))
    <div
        class="mb-6 bg-emerald-50 border border-emerald-200 text-emerald-700 px-4 py-3 rounded-xl text-sm shadow-sm flex items-center justify-between">
        <span>{{ session('success') }}</span>
    </div>
    @endif

    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div>
            <h2 class="text-xl font-bold text-slate-900">Rekap Nilai Kekhasan Peserta Didik</h2>
            <p class="text-sm text-slate-500">Ringkasan predikat Tahfidzul Quran, Qiroaty, dan Bina Pribadi Islami
                (BPI).</p>
        </div>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-5 mb-6">
        <form method="GET" action="{{ route('admin.kekhasan.index') }}" class="flex items-center gap-4">
            <div class="w-full sm:w-1/3">
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Pilih Kelas</label>
                <select name="kelas_id" onchange="this.form.submit()"
                    class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500">
                    @foreach($kelasList as $kelas)
                    <option value="{{ $kelas->id }}" {{ $kelasId == $kelas->id ? 'selected' : '' }}>
                        {{ $kelas->nama }}
                    </option>
                    @endforeach
                </select>
            </div>
        </form>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-slate-200/80 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr
                        class="bg-slate-50/70 border-b border-slate-200 text-xs font-bold text-slate-500 uppercase tracking-wider">
                        <th class="px-6 py-4">NIS</th>
                        <th class="px-6 py-4">Nama Siswa</th>
                        <th class="px-6 py-4 text-center">Predikat Tahfidz</th>
                        <th class="px-6 py-4 text-center">Predikat Qiroaty</th>
                        <th class="px-6 py-4 text-center">Predikat BPI</th>
                        <th class="px-6 py-4 text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 text-sm text-slate-700">
                    @forelse($nilaiKekhasans as $item)
                    <tr class="hover:bg-slate-50/50 transition">
                        <td class="px-6 py-4 font-semibold text-slate-900">{{ $item->siswa->nis ?? '-' }}</td>
                        <td class="px-6 py-4 font-medium text-slate-800">{{ $item->siswa->user->name ?? '-' }}</td>

                        <td class="px-6 py-4 text-center">
                            @if($item->tahfidz_predikat)
                            <span
                                class="px-3 py-1 text-xs font-bold rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 inline-block">
                                {{ $item->tahfidz_predikat }}
                            </span>
                            @else
                            <span class="text-slate-400 text-xs">-</span>
                            @endif
                        </td>

                        <td class="px-6 py-4 text-center">
                            @if($item->qiroaty_predikat)
                            <span
                                class="px-3 py-1 text-xs font-bold rounded-full bg-blue-50 text-blue-700 border border-blue-200 inline-block">
                                {{ $item->qiroaty_predikat }}
                            </span>
                            @else
                            <span class="text-slate-400 text-xs">-</span>
                            @endif
                        </td>

                        <td class="px-6 py-4 text-center">
                            @if($item->bpi_predikat)
                            <span
                                class="px-3 py-1 text-xs font-bold rounded-full bg-amber-50 text-amber-700 border border-amber-200 inline-block">
                                {{ $item->bpi_predikat }}
                            </span>
                            @else
                            <span class="text-slate-400 text-xs">-</span>
                            @endif
                        </td>

                        <td class="px-6 py-4 text-center">
                            <a href="{{ route('admin.kekhasan.edit', $item->id) }}"
                                class="text-emerald-600 hover:text-emerald-700 font-semibold text-xs bg-emerald-50 hover:bg-emerald-100 px-3 py-1.5 rounded-lg transition inline-block">
                                Edit Rapor
                            </a>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" class="px-6 py-12 text-center text-slate-400 text-sm">
                            Belum ada data nilai kekhasan untuk kelas ini.
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection