@extends('layouts.admin')

@section('title', 'Edit Rapor Kekhasan - SIAKAD SMPIT Insan Mulia')

@section('content')
<div class="max-w-4xl mx-auto">
    <div class="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
            <h2 class="text-xl font-bold text-slate-900">Edit Rapor Kekhasan: {{ $kekhasan->siswa->user->name }}</h2>
            <p class="text-sm text-slate-500">NIS: <span
                    class="font-semibold text-slate-700">{{ $kekhasan->siswa->nis }}</span> | Kelas: <span
                    class="font-semibold text-slate-700">{{ $kekhasan->siswa->kelas->nama ?? '-' }}</span></p>
        </div>
        <a href="{{ route('admin.kekhasan.index', ['kelas_id' => $kekhasan->siswa->kelas_id]) }}"
            class="text-xs bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold px-4 py-2.5 rounded-xl transition flex items-center gap-1">
            &larr; Kembali ke Rekap
        </a>
    </div>

    <form action="{{ route('admin.kekhasan.update', $kekhasan->id) }}" method="POST" class="space-y-6">
        @csrf
        @method('PUT')

        <div class="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-6 space-y-4">
            <div class="flex items-center gap-2 border-b border-slate-100 pb-3">
                <div
                    class="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 font-bold text-sm flex items-center justify-center">
                    1</div>
                <h3 class="text-base font-bold text-slate-900">Pencapaian Tahfidzul Quran</h3>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">No. Surat /
                        Juz</label>
                    <input type="text" id="tahfidz_no_surat" name="tahfidz_no_surat"
                        value="{{ old('tahfidz_no_surat', $kekhasan->tahfidz_no_surat) }}" placeholder="Contoh: 67"
                        class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500">
                </div>
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Nama Surat (114
                        Surah)</label>
                    <select id="select_surat" onchange="updateNomorSurat(this)"
                        class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500">
                        <option value="">-- Pilih Surah Al-Quran --</option>
                        @php
                        $surahs = [
                        1=>'Al-Fatihah', 2=>'Al-Baqarah', 3=>'Ali Imran', 4=>'An-Nisa', 5=>'Al-Maidah', 6=>'Al-Anam',
                        7=>'Al-Araf', 8=>'Al-Anfal', 9=>'At-Taubah', 10=>'Yunus',
                        11=>'Hud', 12=>'Yusuf', 13=>'Ar-Rad', 14=>'Ibrahim', 15=>'Al-Hijr', 16=>'An-Nahl',
                        17=>'Al-Isra', 18=>'Al-Kahf', 19=>'Maryam', 20=>'Taha',
                        21=>'Al-Anbiya', 22=>'Al-Hajj', 23=>'Al-Muminun', 24=>'An-Nur', 25=>'Al-Furqan',
                        26=>'Asy-Syuara', 27=>'An-Naml', 28=>'Al-Qasas', 29=>'Al-Ankabut', 30=>'Ar-Rum',
                        31=>'Luqman', 32=>'As-Sajdah', 33=>'Al-Ahzab', 34=>'Saba', 35=>'Fatir', 36=>'Yasind',
                        37=>'As-Saffat', 38=>'Sad', 39=>'Az-Zumar', 40=>'Gafir',
                        41=>'Fussilat', 42=>'Asy-Syura', 43=>'Az-Zukhruf', 44=>'Ad-Dukhan', 45=>'Al-Jasiyah',
                        46=>'Al-Ahqaf', 47=>'Muhammad', 48=>'Al-Fath', 49=>'Al-Hujurat', 50=>'Qaf',
                        51=>'Ad-Dariyat', 52=>'At-Tur', 53=>'An-Najm', 54=>'Al-Qomar', 55=>'Ar-Rahman', 56=>'Al-Waqiah',
                        57=>'Al-Hadid', 58=>'Al-Mujadalah', 59=>'Al-Hasyr', 60=>'Al-Mumtahanah',
                        61=>'As-Saff', 62=>'Al-Jumuah', 63=>'Al-Munafiqun', 64=>'At-Tagabun', 65=>'At-Talaq',
                        66=>'At-Tahrim', 67=>'Al-Mulk', 68=>'Al-Qolam', 69=>'Al-Haqqah', 70=>'Al-Maarij',
                        71=>'Nuh', 72=>'Al-Jin', 73=>'Al-Muzzammil', 74=>'Al-Muddassir', 75=>'Al-Qiyamah',
                        76=>'Al-Insan', 77=>'Al-Mursalat', 78=>'An-Naba', 79=>'An-Naziat', 80=>'Abasa',
                        81=>'At-Takwir', 82=>'Al-Infitar', 83=>'Al-Mutaffifin', 84=>'Al-Inshiqaq', 85=>'Al-Buruj',
                        86=>'At-Tariq', 87=>'Al-Ala', 88=>'Al-Gasiyah', 89=>'Al-Fajr', 90=>'Al-Balad',
                        91=>'Asy-Syams', 92=>'Al-Lail', 93=>'Ad-Duha', 94=>'Asy-Syarh', 95=>'At-Tin', 96=>'Al-Alaq',
                        97=>'Al-Qadr', 98=>'Al-Bayyinah', 99=>'Az-Zalzalah', 100=>'Al-Adiyat',
                        101=>'Al-Qariah', 102=>'At-Takasur', 103=>'Al-Asr', 104=>'Al-Humazah', 105=>'Al-Fil',
                        106=>'Quraisy', 107=>'Al-Maun', 108=>'Al-Kautsar', 109=>'Al-Kafirun', 110=>'An-Nasr',
                        111=>'Al-Lahab', 112=>'Al-Ikhlas', 113=>'Al-Falaq', 114=>'An-Nas'
                        ];
                        @endphp
                        @foreach($surahs as $no => $nama)
                        <option value="{{ $nama }}" data-no="{{ $no }}"
                            {{ old('tahfidz_nama_surat', $kekhasan->tahfidz_nama_surat) == $nama ? 'selected' : '' }}>
                            {{ $no }}. {{ $nama }}
                        </option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Predikat</label>
                    <select name="tahfidz_predikat"
                        class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500">
                        <option value="">-- Pilih Predikat --</option>
                        <option value="A"
                            {{ old('tahfidz_predikat', $kekhasan->tahfidz_predikat) == 'A' ? 'selected' : '' }}>A
                            (Sangat Baik)</option>
                        <option value="B"
                            {{ old('tahfidz_predikat', $kekhasan->tahfidz_predikat) == 'B' ? 'selected' : '' }}>B (Baik)
                        </option>
                        <option value="C"
                            {{ old('tahfidz_predikat', $kekhasan->tahfidz_predikat) == 'C' ? 'selected' : '' }}>C
                            (Cukup)</option>
                    </select>
                </div>
            </div>
            <div>
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Nama Surat Manual &
                    Deskripsi / Keterangan</label>
                <input type="text" id="tahfidz_nama_surat_manual" name="tahfidz_nama_surat"
                    value="{{ old('tahfidz_nama_surat', $kekhasan->tahfidz_nama_surat) }}"
                    placeholder="Atau ketik nama surat jika gabungan..."
                    class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 mb-2">
                <select onchange="document.getElementById('custom_tahfidz').value = this.value"
                    class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 mb-2">
                    <option value="">-- Pilih Templat Deskripsi / Ketik Manual di Bawah --</option>
                    <option value="TUNTAS">TUNTAS</option>
                    <option value="Murid telah mampu hafal 1/2 juz 3 surat Al-Baqarah dengan sangat baik">Murid telah
                        mampu hafal 1/2 juz 3 surat Al-Baqarah dengan sangat baik</option>
                    <option value="Murid telah sedang menghafal surat Al Mulk sampai ayat 20an dengan Baik">Murid telah
                        sedang menghafal surat Al Mulk sampai ayat 20an dengan Baik</option>
                </select>
                <input type="text" id="custom_tahfidz" name="tahfidz_deskripsi"
                    value="{{ old('tahfidz_deskripsi', $kekhasan->tahfidz_deskripsi) }}"
                    placeholder="Atau ketik deskripsi khusus..."
                    class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500">
            </div>
        </div>

        <div class="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-6 space-y-4">
            <div class="flex items-center gap-2 border-b border-slate-100 pb-3">
                <div
                    class="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 font-bold text-sm flex items-center justify-center">
                    2</div>
                <h3 class="text-base font-bold text-slate-900">Pencapaian Qiroaty</h3>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Capaian /
                        Jilid</label>
                    <div class="flex gap-2">
                        <select id="select_qiroaty" name="qiroaty_jilid"
                            class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500">
                            <option value="">-- Pilih Capaian Jilid --</option>
                            @foreach(['Jilid 1', 'Jilid 2', 'Jilid 3', 'Jilid 4', 'Jilid 5', 'Jilid 6', 'Al Quran',
                            'Pasca Khotmil', 'Ghorib', 'Ghorib dan Tajwid'] as $jilid)
                            <option value="{{ $jilid }}"
                                {{ old('qiroaty_jilid', $kekhasan->qiroaty_jilid) == $jilid ? 'selected' : '' }}>
                                {{ $jilid }}</option>
                            @endforeach
                        </select>
                        <button type="button" onclick="openQiroatyModal()"
                            class="bg-slate-800 hover:bg-slate-900 text-white px-3.5 py-2 rounded-xl text-xs font-semibold transition shrink-0">
                            + Tambah
                        </button>
                    </div>
                </div>
                <div>
                    <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Predikat</label>
                    <select name="qiroaty_predikat"
                        class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500">
                        <option value="">-- Pilih Predikat --</option>
                        <option value="A"
                            {{ old('qiroaty_predikat', $kekhasan->qiroaty_predikat) == 'A' ? 'selected' : '' }}>A
                            (Sangat Baik)</option>
                        <option value="B"
                            {{ old('qiroaty_predikat', $kekhasan->qiroaty_predikat) == 'B' ? 'selected' : '' }}>B (Baik)
                        </option>
                        <option value="Acak"
                            {{ old('qiroaty_predikat', $kekhasan->qiroaty_predikat) == 'Acak' ? 'selected' : '' }}>Acak
                        </option>
                    </select>
                </div>
            </div>
            <div>
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Deskripsi
                    Kemampuan</label>
                <textarea name="qiroaty_deskripsi" rows="3" placeholder="Deskripsi kemampuan membaca Al-Quran..."
                    class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500">{{ old('qiroaty_deskripsi', $kekhasan->qiroaty_deskripsi) }}</textarea>
            </div>
        </div>

        <div class="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-6 space-y-4">
            <div class="flex items-center gap-2 border-b border-slate-100 pb-3">
                <div
                    class="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 font-bold text-sm flex items-center justify-center">
                    3</div>
                <h3 class="text-base font-bold text-slate-900">Bina Pribadi Islami (BPI)</h3>
            </div>
            <div>
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Predikat
                    Karakter</label>
                <select name="bpi_predikat"
                    class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500">
                    <option value="">-- Pilih Predikat Karakter --</option>
                    <option value="Baik" {{ old('bpi_predikat', $kekhasan->bpi_predikat) == 'Baik' ? 'selected' : '' }}>
                        Baik</option>
                    <option value="Sangat Baik"
                        {{ old('bpi_predikat', $kekhasan->bpi_predikat) == 'Sangat Baik' ? 'selected' : '' }}>Sangat
                        Baik</option>
                </select>
            </div>
            <div>
                <label class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">Deskripsi
                    Pembinaan</label>
                <select onchange="document.getElementById('custom_bpi').value = this.value"
                    class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 mb-2">
                    <option value="">-- Pilih Templat Deskripsi / Ketik Manual di Bawah --</option>
                    <option
                        value="Murid mampu memahami tentang thaharah, shalat, mengenal Quran, adab menjaga lisan dan etika bermedia sosial, serta meneladani akhlak rasulullah Muhammad SAW dengan baik.">
                        Murid mampu memahami thaharah, shalat, mengenal Quran, adab lisan & media sosial, serta
                        meneladani akhlak Rasulullah SAW dengan baik.</option>
                    <option
                        value="Murid telah mempelajari materi thoharoh, adab menuntut ilmu, gaya hidup seorang muslimah, tabaruj dan pentingnya kesehatan muslimah (Qowiyul Jism) dengan baik">
                        Murid telah mempelajari thoharoh, adab menuntut ilmu, gaya hidup muslimah, tabaruj & kesehatan
                        muslimah (Qowiyul Jism) dengan baik.</option>
                </select>
                <textarea id="custom_bpi" name="bpi_deskripsi" rows="3" placeholder="Atau ketik deskripsi khusus..."
                    class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500">{{ old('bpi_deskripsi', $kekhasan->bpi_deskripsi) }}</textarea>
            </div>
        </div>

        <button type="submit"
            class="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-3.5 rounded-xl transition shadow-sm text-sm">
            Simpan Perubahan Rapor Kekhasan
        </button>
    </form>
</div>

<div id="qiroatyModal"
    class="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm hidden opacity-0 transition-opacity duration-300">
    <div class="bg-white rounded-2xl shadow-xl border border-slate-100 max-w-md w-full mx-4 p-6 transform scale-95 transition-transform duration-300"
        id="qiroatyModalContainer">
        <h3 class="text-base font-bold text-slate-900 mb-2">Tambah Capaian Qiroaty Baru</h3>
        <p class="text-xs text-slate-500 mb-4">Masukkan nama jilid atau tingkat capaian Qiroaty yang baru untuk
            ditambahkan ke pilihan dropdown.</p>

        <input type="text" id="input_qiroaty_baru" placeholder="Contoh: Jilid 7 / Khotmil"
            class="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 mb-5">

        <div class="flex gap-3">
            <button type="button" onclick="closeQiroatyModal()"
                class="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold py-2.5 rounded-xl transition text-sm">
                Batal
            </button>
            <button type="button" onclick="simpanOpsiQiroaty()"
                class="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-2.5 rounded-xl transition text-sm shadow-sm">
                Tambahkan
            </button>
        </div>
    </div>
</div>

<script>
function updateNomorSurat(select) {
    const selectedOption = select.options[select.selectedIndex];
    const noSurat = selectedOption.getAttribute('data-no');
    const namaSurat = selectedOption.value;

    if (noSurat) {
        document.getElementById('tahfidz_no_surat').value = noSurat;
    }
    if (namaSurat) {
        document.getElementById('tahfidz_nama_surat_manual').value = namaSurat;
    }
}

function openQiroatyModal() {
    const modal = document.getElementById('qiroatyModal');
    const container = document.getElementById('qiroatyModalContainer');
    document.getElementById('input_qiroaty_baru').value = '';

    modal.classList.remove('hidden');
    setTimeout(() => {
        modal.classList.remove('opacity-0');
        container.classList.remove('scale-95');
        container.classList.add('scale-100');
    }, 10);
}

function closeQiroatyModal() {
    const modal = document.getElementById('qiroatyModal');
    const container = document.getElementById('qiroatyModalContainer');

    modal.classList.add('opacity-0');
    container.classList.remove('scale-100');
    container.classList.add('scale-95');
    setTimeout(() => {
        modal.classList.add('hidden');
    }, 300);
}

function simpanOpsiQiroaty() {
    const input = document.getElementById('input_qiroaty_baru').value.trim();
    if (input !== "") {
        const select = document.getElementById('select_qiroaty');
        const option = document.createElement('option');
        option.value = input;
        option.text = input;
        option.selected = true;
        select.appendChild(option);
        closeQiroatyModal();
    }
}
</script>
@endsection