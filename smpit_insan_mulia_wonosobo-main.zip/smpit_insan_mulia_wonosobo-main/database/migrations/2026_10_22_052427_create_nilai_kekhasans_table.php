<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('nilai_kekhasans', function (Blueprint $table) {
            $table->id();
            $table->foreignId('siswa_id')->constrained('siswas')->onDelete('cascade');
            $table->foreignId('tahun_ajaran_id')->constrained('tahun_ajarans')->onDelete('cascade');

            $table->string('tahfidz_no_surat')->nullable();
            $table->string('tahfidz_nama_surat')->nullable();
            $table->string('tahfidz_predikat')->nullable();
            $table->text('tahfidz_deskripsi')->nullable();

            $table->string('qiroaty_jilid')->nullable();
            $table->string('qiroaty_predikat')->nullable();
            $table->text('qiroaty_deskripsi')->nullable();

            $table->string('bpi_kriteria')->default('Akhlaq, siroh, dan ibadah');
            $table->string('bpi_predikat')->nullable();
            $table->text('bpi_deskripsi')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('nilai_kekhasans');
    }
};