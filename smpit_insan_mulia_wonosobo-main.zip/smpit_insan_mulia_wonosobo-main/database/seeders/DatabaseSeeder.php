<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Models\TahunAjaran;
use App\Models\Guru;
use App\Models\Kelas;
use App\Models\Siswa;
use App\Models\MataPelajaran;
use App\Models\NilaiKekhasan;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // 1. Tahun Ajaran
        $tahun = TahunAjaran::create([
            'nama' => '2025/2026',
            'semester' => 'Ganjil',
            'is_aktif' => true,
        ]);

        // 2. User & Data Admin
        User::create([
            'name' => 'Administrator Sekolah',
            'username' => 'admin',
            'email' => 'admin@siakad.test',
            'password' => Hash::make('password'),
            'role' => 'admin',
        ]);

        // 3. User & Data Wali Kelas, tambahkan wwali lain disini
        $userGuru = User::create([
            'name' => 'Titan Widyo Buwono, S.Pd.',
            'username' => 'titan',
            'email' => 'titan@siakad.test',
            'password' => Hash::make('password'),
            'role' => 'guru',
        ]);

        $guru = Guru::create([
            'user_id' => $userGuru->id,
            'nip' => '199001012020011001',
            'jenis_kelamin' => 'L',
            'no_hp' => '081234567890',
        ]);

        // 4. Data Kelas (IX Ar Rahman)
        $kelas = Kelas::create([
            'nama' => 'IX Ar Rahman',
            'tingkat' => 9,
            'wali_kelas_id' => $guru->id,
        ]);

        // 5. Data Siswa & Nilai Kekhasan Berdasarkan Dokumen Rapor
        $dataRaporSiswa = [
            [
                'name' => 'Alfatih Enggar Gaezatin', 'nis' => '0261', 'jk' => 'L',
                'tahfidz' => ['no' => '67', 'surat' => 'Al-Mulk', 'predikat' => 'B', 'desc' => 'TUNTAS'],
                'qiroaty' => ['jilid' => '2', 'predikat' => 'B', 'desc' => 'Murid mampu memahami bacaan lam sukun, mengetahui bacaan alif dan wawu, mengetahui bacaan alif dan ya namun kurang memahami panjang pendek bacaan.'],
                'bpi' => ['predikat' => 'Baik', 'desc' => 'Murid mampu memahami tentang thaharah, shalat, mengenal Quran, adab menjaga lisan dan etika bermedia sosial, serta meneladani akhlak rasulullah Muhammad SAW dengan baik.']
            ],
            [
                'name' => 'Alif Al Rahman', 'nis' => '0262', 'jk' => 'L',
                'tahfidz' => ['no' => '67', 'surat' => 'Al-Mulk', 'predikat' => 'B', 'desc' => 'TUNTAS'],
                'qiroaty' => ['jilid' => '4', 'predikat' => 'B', 'desc' => 'Murid mampu memahami tanda waqaf, bacaan qalqalah, idzhar, dan fawatikhus suwar dengan baik'],
                'bpi' => ['predikat' => 'Sangat baik', 'desc' => 'Murid mampu memahami tentang thaharah, shalat, mengenal Quran, adab menjaga lisan dan etika bermedia sosial, serta meneladani akhlak rasulullah Muhammad SAW dengan sangat baik.']
            ],
            [
                'name' => 'Alziza Budi Maulana', 'nis' => '0304', 'jk' => 'L',
                'tahfidz' => ['no' => '67', 'surat' => 'Al-Mulk', 'predikat' => 'B', 'desc' => 'TUNTAS'],
                'qiroaty' => ['jilid' => 'Al Quran', 'predikat' => 'B', 'desc' => "Murid mampu membaca Al-Qur'an dengan baik dan tartil, menerapkan makhrojul huruf dengan sangat baik."],
                'bpi' => ['predikat' => 'Baik', 'desc' => 'Murid mampu memahami tentang thaharah, shalat, menjaga adab dan lisan serta merawat diri dan lingkungan dengan baik']
            ],
            [
                'name' => 'Astri Raisyafina', 'nis' => '0263', 'jk' => 'P',
                'tahfidz' => ['no' => '45, 56, 57', 'surat' => 'Al-Jasiyah, Al-Ahqaf, Muhammad', 'predikat' => 'A', 'desc' => 'TUNTAS'],
                'qiroaty' => ['jilid' => 'Ghorib', 'predikat' => 'A', 'desc' => 'Murid mampu menghafal dan menerapkan kaidah ghorib dengan sangat baik.'],
                'bpi' => ['predikat' => 'Baik', 'desc' => 'Murid telah mempelajari materi thoharoh, adab menuntut ilmu, gaya hidup seorang muslimah, tabaruj dan pentingnya kesehatan muslimah (Qowiyul Jism)']
            ],
            [
                'name' => 'Attalla Rayya El-Ghazaly', 'nis' => '0264', 'jk' => 'L',
                'tahfidz' => ['no' => '58, 59, 60', 'surat' => 'Al-Mujadalah, Al-Hasyr, Al Mumtahanah', 'predikat' => 'A / B', 'desc' => 'TUNTAS'],
                'qiroaty' => ['jilid' => 'Pasca Khotmil', 'predikat' => 'A', 'desc' => "murid mampu membaca Al-Qur'an dengan sangat baik."],
                'bpi' => ['predikat' => 'Baik', 'desc' => 'Murid mampu memahami tentang thaharah, shalat, mengenal Quran, adab menjaga lisan dan etika bermedia sosial, serta meneladani akhlak rasulullah Muhammad SAW dengan baik.']
            ],
            [
                'name' => 'AYAT AKHRAS', 'nis' => '0265', 'jk' => 'L',
                'tahfidz' => ['no' => '45, 46, 47', 'surat' => 'Al-Jasiyah, Al-Ahqaf, Muhammad', 'predikat' => 'A', 'desc' => 'TUNTAS'],
                'qiroaty' => ['jilid' => 'Ghorib', 'predikat' => 'A', 'desc' => 'Murid mampu menghafal dan menerapkan kaidah ghorib dengan sangat baik.'],
                'bpi' => ['predikat' => 'Baik', 'desc' => 'Murid telah mempelajari materi thoharoh, adab menuntut ilmu, gaya hidup seorang muslimah, tabaruj dan pentingnya kesehatan muslimah (Qowiyul Jism) dengan baik']
            ],
            [
                'name' => 'Derice Mahla Delnavaz Arrayka', 'nis' => '0266', 'jk' => 'P',
                'tahfidz' => ['no' => '46, 47, 51', 'surat' => 'Al Ahqaf, Muhammad, At-Dariyat', 'predikat' => 'A / B', 'desc' => 'TUNTAS'],
                'qiroaty' => ['jilid' => 'Pasca Khotmil', 'predikat' => 'A', 'desc' => "murid mampu membaca Al-Qur'an dengan sangat baik."],
                'bpi' => ['predikat' => 'Sangat Baik', 'desc' => 'Murid telah mempelajari materi thoharoh, adab menuntut ilmu, gaya hidup seorang muslimah, tabaruj dan pentingnya kesehatan muslimah (Qowiyul Jism) dengan sangat baik']
            ],
            [
                'name' => 'Devka Arka Putra', 'nis' => '0286', 'jk' => 'L',
                'tahfidz' => ['no' => '2', 'surat' => 'Al-Baqarah (1/2 Juz)', 'predikat' => 'B', 'desc' => 'Murid telah mampu hafal 1/2 juz 3 surat Al-Baqarah dengan sangat baik'],
                'qiroaty' => ['jilid' => 'Ghorib dan Tajwid', 'predikat' => 'A', 'desc' => 'Murid mampu menghafal dan menerapkan kaidah ghorib dengan sangat baik.'],
                'bpi' => ['predikat' => 'Sangat Baik', 'desc' => 'Murid mampu memahami tentang thaharah, shalat, menjaga adab dan lisan serta merawat diri dan lingkungan dengan baik']
            ],
            [
                'name' => 'DHIA SILMI ATIYAH', 'nis' => '0267', 'jk' => 'P',
                'tahfidz' => ['no' => '67', 'surat' => 'Al Mulk', 'predikat' => '-', 'desc' => 'Murid telah sedang menghafal surat Al Mulk sampai ayat 20an dengan Baik'],
                'qiroaty' => ['jilid' => '3', 'predikat' => 'B', 'desc' => "Murid mampu membaca bacaan ikhfa' (nun sukun dan tanwin), ghunnah, idghom dengan baik."],
                'bpi' => ['predikat' => 'Baik', 'desc' => 'Murid telah mempelajari materi thoharoh, adab menuntut ilmu, gaya hidup seorang muslimah, tabaruj dan pentingnya kesehatan muslimah (Qowiyul Jism) dengan baik']
            ],
            [
                'name' => 'Dinda Fatkhulia Karima', 'nis' => '0268', 'jk' => 'P',
                'tahfidz' => ['no' => '67, 68', 'surat' => 'Al Mulk, Al Qolam', 'predikat' => 'A', 'desc' => 'TUNTAS'],
                'qiroaty' => ['jilid' => 'Al Quran', 'predikat' => 'B', 'desc' => "Murid mampu membaca Al-Qur'an dengan baik dan tartil, menerapkan makhrojul huruf dengan sangat baik."],
                'bpi' => ['predikat' => 'Sangat Baik', 'desc' => 'Murid telah mempelajari materi thoharoh, adab menuntut ilmu, gaya hidup seorang muslimah, tabaruj dan pentingnya kesehatan muslimah (Qowiyul Jism) dengan sangat baik']
            ],
            [
                'name' => 'Farhan Ilham Rahman', 'nis' => '0269', 'jk' => 'L',
                'tahfidz' => ['no' => '67', 'surat' => 'Al-Mulk', 'predikat' => 'B', 'desc' => 'TUNTAS'],
                'qiroaty' => ['jilid' => '3', 'predikat' => 'B', 'desc' => "Murid mampu membaca bacaan ikhfa' (nun sukun dan tanwin), ghunnah, idghom dengan baik."],
                'bpi' => ['predikat' => 'Baik', 'desc' => 'Murid mampu memahami tentang thaharah, shalat, mengenal Quran, adab menjaga lisan dan etika bermedia sosial, serta meneladani akhlak rasulullah Muhammad SAW dengan baik.']
            ],
            [
                'name' => 'Fayyadh Irkham Rafasya', 'nis' => '0270', 'jk' => 'L',
                'tahfidz' => ['no' => '58, 59, 60', 'surat' => 'Al-Mujadalah, Al-Hasyr, Al Mumtahanah', 'predikat' => 'A / B', 'desc' => 'TUNTAS'],
                'qiroaty' => ['jilid' => 'Ghorib dan Tajwid', 'predikat' => 'A', 'desc' => 'Murid mampu menghafal dan menerapkan kaidah ghorib dengan sangat baik.'],
                'bpi' => ['predikat' => 'Sangat Baik', 'desc' => 'Murid mampu memahami tentang thaharah, shalat, menjaga adab dan lisan serta merawat diri dan lingkungan dengan baik']
            ],
            [
                'name' => 'Hidayatunna Arofah Kinasiha', 'nis' => '0271', 'jk' => 'P',
                'tahfidz' => ['no' => '52-56', 'surat' => 'At-Tur, An-Najm, Al-Qomar, Ar-Rahman, Al-Waqiah', 'predikat' => 'A', 'desc' => 'TUNTAS'],
                'qiroaty' => ['jilid' => 'Pasca Khotmil', 'predikat' => 'A', 'desc' => "murid mampu membaca Al-Qur'an dengan sangat baik."],
                'bpi' => ['predikat' => 'Sangat Baik', 'desc' => 'Murid telah mempelajari materi thoharoh, adab menuntut ilmu, gaya hidup seorang muslimah, tabaruj dan pentingnya kesehatan muslimah (Qowiyul Jism) dengan sangat baik']
            ],
            [
                'name' => 'Kayla Syakira Azumi', 'nis' => '0272', 'jk' => 'P',
                'tahfidz' => ['no' => '67', 'surat' => 'Al-Mulk', 'predikat' => 'B', 'desc' => 'TUNTAS'],
                'qiroaty' => ['jilid' => '3', 'predikat' => 'B', 'desc' => "Murid mampu membaca bacaan ikhfa' (nun sukun dan tanwin), ghunnah, idghom, idghom bilaghunnah, nun sukun bertemu ya',mim, dan wawu dengan baik."],
                'bpi' => ['predikat' => 'Baik', 'desc' => 'Murid telah mempelajari materi thoharoh, adab menuntut ilmu, gaya hidup seorang muslimah, tabaruj dan pentingnya kesehatan muslimah (Qowiyul Jism) dengan baik']
            ],
            [
                'name' => 'Mahira Dahayu Braganingtyas', 'nis' => '0273', 'jk' => 'P',
                'tahfidz' => ['no' => '67, 68', 'surat' => 'Al Mulk, Al Qolam', 'predikat' => 'A / B', 'desc' => 'TUNTAS'],
                'qiroaty' => ['jilid' => 'Al Quran', 'predikat' => 'B', 'desc' => "Murid mampu membaca bacaan ikhfa' (nun sukun dan tanwin), ghunnah, idghom, idghom bilaghunnah, nun sukun bertemu ya',mim, dan wawu dengan baik."],
                'bpi' => ['predikat' => 'Baik', 'desc' => 'Murid telah mempelajari materi thoharoh, adab menuntut ilmu, gaya hidup seorang muslimah, tabaruj dan pentingnya kesehatan muslimah (Qowiyul Jism) dengan baik']
            ],
            [
                'name' => 'Maura Indah Aninditya', 'nis' => '0274', 'jk' => 'P',
                'tahfidz' => ['no' => '57, 58', 'surat' => 'At-Mujadalah, Al-Hadid', 'predikat' => 'A / B', 'desc' => 'TUNTAS'],
                'qiroaty' => ['jilid' => 'Pasca Khotmil', 'predikat' => 'A', 'desc' => "murid mampu membaca Al-Qur'an dengan sangat baik."],
                'bpi' => ['predikat' => 'Baik', 'desc' => 'Murid telah mempelajari materi thoharoh, adab menuntut ilmu, gaya hidup seorang muslimah, tabaruj dan pentingnya kesehatan muslimah (Qowiyul Jism) dengan baik']
            ],
            [
                'name' => 'Muhamad Gerwyn Putra Listriandy', 'nis' => '0275', 'jk' => 'L',
                'tahfidz' => ['no' => '58, 59', 'surat' => 'Al-Mujadalah, Al-Hasyr', 'predikat' => 'A / B', 'desc' => 'TUNTAS'],
                'qiroaty' => ['jilid' => 'Al-Qur’an', 'predikat' => 'B', 'desc' => "Murid mampu membaca Al-Qur'an dengan baik dan tartil, menerapkan makhrojul huruf dengan sangat baik."],
                'bpi' => ['predikat' => 'Baik', 'desc' => 'Murid mampu memahami tentang thaharah, shalat, menjaga adab dan lisan serta merawat diri dan lingkungan dengan baik']
            ],
            [
                'name' => 'Muhammad Asraf Adian Khaqi', 'nis' => '0310', 'jk' => 'L',
                'tahfidz' => ['no' => '67', 'surat' => 'Al-Mulk', 'predikat' => 'B', 'desc' => 'TUNTAS'],
                'qiroaty' => ['jilid' => '2', 'predikat' => 'Acak', 'desc' => 'Murid mampu memahami panjang pendek, bacaan lam sukun, mengetahui bacaan alif dan wawu, mengetahui bacaan alif dan ya.'],
                'bpi' => ['predikat' => 'Baik', 'desc' => 'Murid mampu memahami tentang thaharah, shalat, menjaga adab dan lisan serta merawat diri dan lingkungan dengan baik']
            ],
            [
                'name' => 'Muhammad Farras Azzam', 'nis' => '0305', 'jk' => 'L',
                'tahfidz' => ['no' => '58, 59, 60', 'surat' => 'Al-Mujadalah, Al-Hasyr, Al-Mumtahanah', 'predikat' => 'A', 'desc' => 'TUNTAS'],
                'qiroaty' => ['jilid' => 'Pasca Khotmil', 'predikat' => 'A', 'desc' => "murid mampu membaca Al-Qur'an dengan sangat baik."],
                'bpi' => ['predikat' => 'Sangat Baik', 'desc' => 'Murid mampu memahami tentang thaharah, shalat, menjaga adab dan lisan serta merawat diri dan lingkungan dengan baik']
            ],
            [
                'name' => 'Muhammad Raffa El Haydar', 'nis' => '0276', 'jk' => 'L',
                'tahfidz' => ['no' => '67', 'surat' => 'Al-Mulk', 'predikat' => 'B', 'desc' => 'TUNTAS'],
                'qiroaty' => ['jilid' => '4', 'predikat' => 'B', 'desc' => 'Murid mampu memahami tanda waqaf, bacaan qalqalah, idzhar, dan fawatikhus suwar dengan baik'],
                'bpi' => ['predikat' => 'Baik', 'desc' => 'Murid mampu memahami tentang thaharah, shalat, mengenal Quran, adab menjaga lisan dan etika bermedia sosial, serta meneladani akhlak rasulullah Muhammad SAW dengan baik.']
            ],
            [
                'name' => 'Nasywa Tyora Syahquitta', 'nis' => '0277', 'jk' => 'P',
                'tahfidz' => ['no' => '58, 58', 'surat' => 'Al-Mujadalah, At-Hasyr', 'predikat' => 'A', 'desc' => 'TUNTAS'],
                'qiroaty' => ['jilid' => 'Pasca Khotmil', 'predikat' => 'A', 'desc' => "murid mampu membaca Al-Qur'an dengan sangat baik."],
                'bpi' => ['predikat' => 'Sangat Baik', 'desc' => 'Murid telah mempelajari materi thoharoh, adab menuntut ilmu, gaya hidup seorang muslimah, tabaruj dan pentingnya kesehatan muslimah (Qowiyul Jism) dengan sangat baik']
            ],
            [
                'name' => 'Riski Syahril Azzam', 'nis' => '0278', 'jk' => 'L',
                'tahfidz' => ['no' => '67', 'surat' => 'Al-Mulk', 'predikat' => 'B', 'desc' => 'TUNTAS'],
                'qiroaty' => ['jilid' => 'Pasca Khotmil', 'predikat' => 'A', 'desc' => "murid mampu membaca Al-Qur'an dengan sangat baik."],
                'bpi' => ['predikat' => 'Baik', 'desc' => 'Murid mampu memahami tentang thaharah, shalat, menjaga adab dan lisan serta merawat diri dan lingkungan dengan baik']
            ],
            [
                'name' => 'Rosada Aulia Azzahra', 'nis' => '0279', 'jk' => 'P',
                'tahfidz' => ['no' => '52, 53, 54', 'surat' => 'At-Tur, An-Najm, Al-Qomar', 'predikat' => 'A', 'desc' => 'TUNTAS'],
                'qiroaty' => ['jilid' => 'Pasca Khotmil', 'predikat' => 'A', 'desc' => "murid mampu membaca Al-Qur'an dengan sangat baik."],
                'bpi' => ['predikat' => 'Sangat Baik', 'desc' => 'Murid telah mempelajari materi thoharoh, adab menuntut ilmu, gaya hidup seorang muslimah, tabaruj dan pentingnya kesehatan muslimah (Qowiyul Jism) dengan sangat baik']
            ],
            [
                'name' => 'Sabrina Rihaadatul Aisya', 'nis' => '0280', 'jk' => 'P',
                'tahfidz' => ['no' => '58, 59, 60, 57', 'surat' => 'Al Mujadalah, Al Hasyr, Al Mumtahanah, Al Hadid', 'predikat' => 'A', 'desc' => 'TUNTAS'],
                'qiroaty' => ['jilid' => 'Ghorib dan Tajwid', 'predikat' => 'A', 'desc' => 'Murid mampu menghafal dan menerapkan kaidah ghorib dengan sangat baik.'],
                'bpi' => ['predikat' => 'Sangat Baik', 'desc' => 'Murid telah mempelajari materi thoharoh, adab menuntut ilmu, gaya hidup seorang muslimah, tabaruj dan pentingnya kesehatan muslimah (Qowiyul Jism) dengan sangat baik']
            ],
            [
                'name' => 'Shaqeena Azzahra Hana Zafiriah', 'nis' => '0257', 'jk' => 'P',
                'tahfidz' => ['no' => '58, 59', 'surat' => 'Al-Mujadalah, Al-Hasyr', 'predikat' => 'B', 'desc' => 'TUNTAS'],
                'qiroaty' => ['jilid' => 'Ghorib', 'predikat' => 'A', 'desc' => 'Murid mampu menghafal dan menerapkan kaidah ghorib dengan sangat baik.'],
                'bpi' => ['predikat' => 'Baik', 'desc' => 'Murid telah mempelajari materi thoharoh, adab menuntut ilmu, gaya hidup seorang muslimah, tabaruj dan pentingnya kesehatan muslimah (Qowiyul Jism) dengan sangat baik']
            ],
        ];

        foreach ($dataRaporSiswa as $dataSiswa) {
            $userSiswa = User::create([
                'name' => $dataSiswa['name'],
                'username' => strtolower(explode(' ', trim($dataSiswa['name']))[0]) . $dataSiswa['nis'],
                'email' => 'siswa_' . $dataSiswa['nis'] . '@siakad.test',
                'password' => Hash::make('password'),
                'role' => 'siswa',
            ]);

            $siswaModel = Siswa::create([
                'user_id' => $userSiswa->id,
                'nis' => $dataSiswa['nis'],
                'nisn' => '008' . rand(1000000, 9999999),
                'kelas_id' => $kelas->id,
                'jenis_kelamin' => $dataSiswa['jk'],
                'status' => 'aktif',
            ]);

            // Nilai Kekhasan Sesuai Dokumen Rapor
            NilaiKekhasan::create([
                'siswa_id' => $siswaModel->id,
                'tahun_ajaran_id' => $tahun->id,
                'tahfidz_no_surat' => $dataSiswa['tahfidz']['no'],
                'tahfidz_nama_surat' => $dataSiswa['tahfidz']['surat'],
                'tahfidz_predikat' => $dataSiswa['tahfidz']['predikat'],
                'tahfidz_deskripsi' => $dataSiswa['tahfidz']['desc'],
                'qiroaty_jilid' => $dataSiswa['qiroaty']['jilid'],
                'qiroaty_predikat' => $dataSiswa['qiroaty']['predikat'],
                'qiroaty_deskripsi' => $dataSiswa['qiroaty']['desc'],
                'bpi_kriteria' => 'Akhlaq, siroh, dan ibadah',
                'bpi_predikat' => $dataSiswa['bpi']['predikat'],
                'bpi_deskripsi' => $dataSiswa['bpi']['desc'],
            ]);
        }

        // 6. Data Mata Pelajaran Kekhasan
        $mapels = [
            ['kode' => 'TAHFIDZ', 'nama' => 'Tahfidzul Quran', 'kelompok' => 'Kekhasan'],
            ['kode' => 'QIROATY', 'nama' => 'Qiroaty', 'kelompok' => 'Kekhasan'],
            ['kode' => 'BPI', 'nama' => 'Bina Pribadi Islami (BPI)', 'kelompok' => 'Kekhasan'],
        ];

        foreach ($mapels as $mapel) {
            MataPelajaran::create($mapel);
        }
    }
}