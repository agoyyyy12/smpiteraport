<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\ClassroomController;
use App\Http\Controllers\TeacherController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\AcademicYearController;
use App\Http\Controllers\SubjectController;
use App\Http\Controllers\ScheduleController;
use App\Http\Controllers\AttendanceController;
use App\Http\Controllers\NilaiKekhasanController;
use App\Http\Controllers\ReportController;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/home', function () {
    $tahunAktif = \App\Models\TahunAjaran::where('is_aktif', true)->first();
    $totalKelas = \App\Models\Kelas::count();
    $totalGuru = \App\Models\Guru::count();
    $totalSiswa = \App\Models\Siswa::where('status', 'aktif')->count();

    return view('dashboard.admin', compact('tahunAktif', 'totalKelas', 'totalGuru', 'totalSiswa'));
})->name('home')->middleware(['auth', 'admin']);

// Rute login
Route::middleware('guest')->group(function () {
    Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [LoginController::class, 'login'])->middleware('throttle:5,1');
});

Route::post('/logout', function (Request $request) {
    Auth::logout();
    $request->session()->invalidate();
    $request->session()->regenerateToken();
    return redirect('/');
})->name('logout');

Route::middleware(['auth', 'admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::resource('classrooms', ClassroomController::class);
    Route::resource('teachers', TeacherController::class);
    Route::resource('students', StudentController::class);
    Route::resource('academic-years', AcademicYearController::class);
    Route::resource('subjects', SubjectController::class);
    Route::resource('schedules', ScheduleController::class);

    // Rute Absensi
    Route::get('attendances', [AttendanceController::class, 'index'])->name('attendances.index');
    Route::get('attendances/create', [AttendanceController::class, 'create'])->name('attendances.create');
    Route::post('attendances', [AttendanceController::class, 'store'])->name('attendances.store');

    // Rute Nilai Kekhasan (Tahfidz, Qiroaty, BPI)
    Route::get('kekhasan', [NilaiKekhasanController::class, 'index'])->name('kekhasan.index');
    Route::get('kekhasan/{kekhasan}/edit', [NilaiKekhasanController::class, 'edit'])->name('kekhasan.edit');
    Route::put('kekhasan/{kekhasan}', [NilaiKekhasanController::class, 'update'])->name('kekhasan.update');

    // Rute Raport
    Route::get('reports', [ReportController::class, 'index'])->name('reports.index');
    Route::get('reports/student/{id}', [ReportController::class, 'show'])->name('reports.show');
});