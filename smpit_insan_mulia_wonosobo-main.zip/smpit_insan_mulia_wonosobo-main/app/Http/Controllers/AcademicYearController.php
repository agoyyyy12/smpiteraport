<?php

namespace App\Http\Controllers;

use App\Models\TahunAjaran;
use Illuminate\Http\Request;

class AcademicYearController extends Controller
{
    public function index(Request $request)
    {
        $query = TahunAjaran::latest();

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('nama', 'like', "%{$search}%")
                    ->orWhere('semester', 'like', "%{$search}%");
            });
        }

        if ($request->filled('status')) {
            $isAktif = $request->status === 'aktif';
            $query->where('is_aktif', $isAktif);
        }

        $tahunAjarans = $query->get();

        return view('admin.academic_years.index', compact('tahunAjarans'));
    }

    public function create()
    {
        return view('admin.academic_years.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
            'semester' => 'required|in:Ganjil,Genap',
            'is_aktif' => 'boolean',
        ]);

        if ($request->has('is_aktif') && $request->is_aktif) {
            TahunAjaran::query()->update(['is_aktif' => false]);
        }

        TahunAjaran::create([
            'nama' => $request->nama,
            'semester' => $request->semester,
            'is_aktif' => $request->has('is_aktif'),
        ]);

        return redirect()->route('admin.academic-years.index')->with('success', 'Tahun ajaran berhasil ditambahkan.');
    }

    public function edit(TahunAjaran $academicYear)
    {
        return view('admin.academic_years.edit', compact('academicYear'));
    }

    public function update(Request $request, TahunAjaran $academicYear)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
            'semester' => 'required|in:Ganjil,Genap',
            'is_aktif' => 'boolean',
        ]);

        if ($request->has('is_aktif') && $request->is_aktif) {
            TahunAjaran::query()->update(['is_aktif' => false]);
        }

        $academicYear->update([
            'nama' => $request->nama,
            'semester' => $request->semester,
            'is_aktif' => $request->has('is_aktif'),
        ]);

        return redirect()->route('admin.academic-years.index')->with('success', 'Tahun ajaran berhasil diperbarui.');
    }

    public function destroy(TahunAjaran $academicYear)
    {
        $academicYear->delete();
        return redirect()->route('admin.academic-years.index')->with('success', 'Tahun ajaran berhasil dihapus.');
    }
}