<?php

namespace App\Http\Controllers;

use App\Models\JadwalPelajaran;
use App\Models\Kelas;
use App\Models\MataPelajaran;
use App\Models\Guru;
use App\Models\TahunAjaran;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Carbon\Carbon;

class ScheduleController extends Controller
{
    public function index(Request $request)
    {
        $query = JadwalPelajaran::with(['kelas', 'mataPelajaran', 'guru.user', 'tahunAjaran'])->latest();

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('kode', 'like', "%{$search}%")
                    ->orWhereHas('mataPelajaran', function ($sub) use ($search) {
                        $sub->where('nama', 'like', "%{$search}%");
                    })
                    ->orWhereHas('guru.user', function ($usr) use ($search) {
                        $usr->where('name', 'like', "%{$search}%");
                    });
            });
        }

        if ($request->filled('hari')) {
            $query->where('hari', $request->hari);
        }

        $schedules = $query->get();
        return view('admin.schedules.index', compact('schedules'));
    }

    public function create()
    {
        $kelasList = Kelas::all();
        $subjects = MataPelajaran::all();
        $teachers = Guru::with('user')->get();
        $tahunAjarans = TahunAjaran::all();
        return view('admin.schedules.create', compact('kelasList', 'subjects', 'teachers', 'tahunAjarans'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'tahun_ajaran_id' => 'required|exists:tahun_ajarans,id',
            'kelas_id' => 'required|exists:kelas,id',
            'mata_pelajaran_id' => 'required|exists:mata_pelajarans,id',
            'guru_id' => 'required|exists:gurus,id',
            'hari' => 'required|in:Senin,Selasa,Rabu,Kamis,Jumat,Sabtu',
            'jam_mulai' => 'required',
            'jam_selesai' => 'required|after:jam_mulai',
            'generate_mode' => 'required|in:auto,manual',
            'kode' => 'required_if:generate_mode,manual|nullable|string|max:50|unique:jadwal_pelajarans,kode',
        ]);

        if ($request->generate_mode === 'auto') {
            $kode = $this->generateTerstrukturKode($request->kelas_id, $request->hari);
        } else {
            $kode = strtoupper(trim($request->kode));
        }

        $data = $request->except(['generate_mode']);
        $data['kode'] = $kode;

        $data['jam_mulai'] = Carbon::parse($request->jam_mulai)->format('H:i');
        $data['jam_selesai'] = Carbon::parse($request->jam_selesai)->format('H:i');

        JadwalPelajaran::create($data);

        return redirect()->route('admin.schedules.index')->with('success', 'Jadwal pelajaran berhasil ditambahkan.');
    }

    public function edit(JadwalPelajaran $schedule)
    {
        $kelasList = Kelas::all();
        $subjects = MataPelajaran::all();
        $teachers = Guru::with('user')->get();
        $tahunAjarans = TahunAjaran::all();
        return view('admin.schedules.edit', compact('schedule', 'kelasList', 'subjects', 'teachers', 'tahunAjarans'));
    }

    public function update(Request $request, JadwalPelajaran $schedule)
    {
        $request->validate([
            'tahun_ajaran_id' => 'required|exists:tahun_ajarans,id',
            'kelas_id' => 'required|exists:kelas,id',
            'mata_pelajaran_id' => 'required|exists:mata_pelajarans,id',
            'guru_id' => 'required|exists:gurus,id',
            'hari' => 'required|in:Senin,Selasa,Rabu,Kamis,Jumat,Sabtu',
            'jam_mulai' => 'required',
            'jam_selesai' => 'required|after:jam_mulai',
            'generate_mode' => 'required|in:auto,manual',
            'kode' => 'required_if:generate_mode,manual|nullable|string|max:50|unique:jadwal_pelajarans,kode,' . $schedule->id,
        ]);

        if ($request->generate_mode === 'auto') {
            $kode = $this->generateTerstrukturKode($request->kelas_id, $request->hari);
        } else {
            $kode = strtoupper(trim($request->kode));
        }

        $data = $request->except(['generate_mode']);
        $data['kode'] = $kode;

        $data['jam_mulai'] = Carbon::parse($request->jam_mulai)->format('H:i');
        $data['jam_selesai'] = Carbon::parse($request->jam_selesai)->format('H:i');

        $schedule->update($data);

        return redirect()->route('admin.schedules.index')->with('success', 'Jadwal pelajaran berhasil diperbarui.');
    }

    public function destroy(JadwalPelajaran $schedule)
    {
        $schedule->delete();
        return redirect()->route('admin.schedules.index')->with('success', 'Jadwal pelajaran berhasil dihapus.');
    }

    private function generateTerstrukturKode($kelasId, $hari)
    {
        $kelas = Kelas::find($kelasId);
        $namaKelas = $kelas ? strtoupper(preg_replace('/[^a-zA-Z0-9]/', '', $kelas->nama)) : 'KLS';
        $singkatanHari = strtoupper(substr($hari, 0, 3));

        $baseKode = "JDW-{$namaKelas}-{$singkatanHari}";
        $kode = $baseKode . '-01';
        $counter = 1;

        while (JadwalPelajaran::where('kode', $kode)->exists()) {
            $counterStr = str_pad($counter, 2, '0', STR_PAD_LEFT);
            $kode = "{$baseKode}-{$counterStr}";
            $counter++;
        }

        return $kode;
    }
}