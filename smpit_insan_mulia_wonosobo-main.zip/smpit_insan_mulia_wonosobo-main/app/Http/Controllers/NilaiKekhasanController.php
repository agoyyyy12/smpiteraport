<?php

namespace App\Http\Controllers;

use App\Models\NilaiKekhasan;
use App\Models\Kelas;
use App\Models\Siswa;
use App\Models\TahunAjaran;
use Illuminate\Http\Request;

class NilaiKekhasanController extends Controller
{
    public function index(Request $request)
    {
        $kelasId = $request->get('kelas_id', Kelas::first()?->id);
        $kelasList = Kelas::all();

        $nilaiKekhasans = [];
        if ($kelasId) {
            $nilaiKekhasans = NilaiKekhasan::with(['siswa.user', 'tahunAjaran'])
                ->whereHas('siswa', function ($q) use ($kelasId) {
                    $q->where('kelas_id', $kelasId);
                })->get();
        }

        return view('admin.kekhasan.index', compact('kelasList', 'nilaiKekhasans', 'kelasId'));
    }

    public function edit(NilaiKekhasan $kekhasan)
    {
        return view('admin.kekhasan.edit', compact('kekhasan'));
    }

    public function update(Request $request, NilaiKekhasan $kekhasan)
    {
        $request->validate([
            'tahfidz_nama_surat' => 'nullable|string',
            'tahfidz_predikat' => 'nullable|string',
            'tahfidz_deskripsi' => 'nullable|string',
            'qiroaty_jilid' => 'nullable|string',
            'qiroaty_predikat' => 'nullable|string',
            'qiroaty_deskripsi' => 'nullable|string',
            'bpi_predikat' => 'nullable|string',
            'bpi_deskripsi' => 'nullable|string',
        ]);

        $kekhasan->update($request->all());

        return redirect()->route('admin.kekhasan.index', ['kelas_id' => $kekhasan->siswa->kelas_id])
            ->with('success', 'Data rapor kekhasan berhasil diperbarui.');
    }
}