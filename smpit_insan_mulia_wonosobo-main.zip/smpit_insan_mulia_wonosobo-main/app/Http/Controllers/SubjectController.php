<?php

namespace App\Http\Controllers;

use App\Models\MataPelajaran;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class SubjectController extends Controller
{
    public function index(Request $request)
    {
        $query = MataPelajaran::latest();

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('kode', 'like', "%{$search}%")
                    ->orWhere('nama', 'like', "%{$search}%");
            });
        }

        if ($request->filled('kelompok')) {
            $query->where('kelompok', $request->kelompok);
        }

        $subjects = $query->get();

        return view('admin.subjects.index', compact('subjects'));
    }

    public function create()
    {
        return view('admin.subjects.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
            'kelompok' => 'required|string',
            'generate_mode' => 'required|in:auto,manual',
            'kode' => 'required_if:generate_mode,manual|nullable|string|max:50|unique:mata_pelajarans,kode',
        ]);

        if ($request->generate_mode === 'auto') {
            $kode = $this->generateUniqueHashKode();
        } else {
            $kode = strtoupper(trim($request->kode));
        }

        MataPelajaran::create([
            'kode' => $kode,
            'nama' => ucwords(strtolower(trim($request->nama))),
            'kelompok' => $request->kelompok,
        ]);

        return redirect()->route('admin.subjects.index')->with('success', 'Mata pelajaran berhasil ditambahkan.');
    }

    public function edit(MataPelajaran $subject)
    {
        return view('admin.subjects.edit', compact('subject'));
    }

    public function update(Request $request, MataPelajaran $subject)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
            'kelompok' => 'required|string',
            'generate_mode' => 'required|in:auto,manual',
            'kode' => 'required_if:generate_mode,manual|nullable|string|max:50|unique:mata_pelajarans,kode,' . $subject->id,
        ]);

        if ($request->generate_mode === 'auto') {
            $kode = $this->generateUniqueHashKode();
        } else {
            $kode = strtoupper(trim($request->kode));
        }

        $subject->update([
            'kode' => $kode,
            'nama' => ucwords(strtolower(trim($request->nama))),
            'kelompok' => $request->kelompok,
        ]);

        return redirect()->route('admin.subjects.index')->with('success', 'Mata pelajaran berhasil diperbarui.');
    }

    public function destroy(MataPelajaran $subject)
    {
        $subject->delete();
        return redirect()->route('admin.subjects.index')->with('success', 'Mata pelajaran berhasil dihapus.');
    }

    private function generateUniqueHashKode()
    {
        do {
            $part1 = strtoupper(Str::random(4));
            $part2 = strtoupper(Str::random(4));
            $kode = "MP-{$part1}-{$part2}";

        } while (MataPelajaran::where('kode', $kode)->exists());

        return $kode;
    }
}