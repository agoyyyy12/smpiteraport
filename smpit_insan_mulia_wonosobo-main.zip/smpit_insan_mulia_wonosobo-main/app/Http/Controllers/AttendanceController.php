<?php

namespace App\Http\Controllers;

use App\Models\Absensi;
use App\Models\Kelas;
use App\Models\Siswa;
use Illuminate\Http\Request;

class AttendanceController extends Controller
{
    public function index(Request $request)
    {
        $kelasId = $request->get('kelas_id');
        $tanggal = $request->get('tanggal', date('Y-m-d'));

        $kelasList = Kelas::all();
        $absensis = [];

        if ($kelasId) {
            $absensis = Absensi::with(['siswa', 'kelas'])
                ->where('kelas_id', $kelasId)
                ->where('tanggal', $tanggal)
                ->get();
        }

        return view('admin.attendances.index', compact('kelasList', 'absensis', 'kelasId', 'tanggal'));
    }

    public function create(Request $request)
    {
        $kelasId = $request->get('kelas_id');
        $tanggal = $request->get('tanggal', date('Y-m-d'));
        $kelasList = Kelas::all();
        $siswas = [];

        if ($kelasId) {
            $siswas = Siswa::where('kelas_id', $kelasId)->where('status', 'aktif')->get();
        }

        return view('admin.attendances.create', compact('kelasList', 'siswas', 'kelasId', 'tanggal'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'tanggal' => 'required|date',
            'kelas_id' => 'required|exists:kelas,id',
            'attendance' => 'required|array',
        ]);

        foreach ($request->attendance as $siswaId => $data) {
            Absensi::updateOrCreate(
                [
                    'tanggal' => $request->tanggal,
                    'kelas_id' => $request->kelas_id,
                    'siswa_id' => $siswaId,
                ],
                [
                    'status' => $data['status'],
                    'keterangan' => $data['keterangan'] ?? null,
                ]
            );
        }

        return redirect()->route('admin.attendances.index', ['kelas_id' => $request->kelas_id, 'tanggal' => $request->tanggal])
            ->with('success', 'Data absensi berhasil disimpan.');
    }
}