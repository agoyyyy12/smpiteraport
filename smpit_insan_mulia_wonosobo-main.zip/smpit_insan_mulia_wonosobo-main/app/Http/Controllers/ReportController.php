<?php

namespace App\Http\Controllers;

use App\Models\Siswa;
use App\Models\Kelas;
use App\Models\Nilai;
use App\Models\Absensi;
use App\Models\NilaiKekhasan;
use App\Models\TahunAjaran;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    public function index(Request $request)
    {
        $kelasId = $request->get('kelas_id');
        $kelasList = Kelas::all();
        $siswas = [];

        if ($kelasId) {
            $siswas = Siswa::with('user')->where('kelas_id', $kelasId)->where('status', 'aktif')->get();
        }

        return view('admin.reports.index', compact('kelasList', 'siswas', 'kelasId'));
    }

    public function show($siswaId, Request $request)
    {
        $siswa = Siswa::with(['user', 'kelas.waliKelas.user'])->findOrFail($siswaId);
        $tahunAktif = TahunAjaran::where('is_aktif', true)->first();

        $nilais = Nilai::with('mataPelajaran')
            ->where('siswa_id', $siswaId)
            ->get();

        $queryKekhasan = NilaiKekhasan::where('siswa_id', $siswaId);
        if ($tahunAktif) {
            $queryKekhasan->where('tahun_ajaran_id', $tahunAktif->id);
        }
        $nilaiKekhasan = $queryKekhasan->latest()->first();

        if (!$nilaiKekhasan) {
            $nilaiKekhasan = NilaiKekhasan::where('siswa_id', $siswaId)->latest()->first();
        }

        $rekapAbsen = Absensi::where('siswa_id', $siswaId)
            ->selectRaw('status, count(*) as total')
            ->groupBy('status')
            ->pluck('total', 'status');

        $hadir = $rekapAbsen['Hadir'] ?? 0;
        $izin = $rekapAbsen['Izin'] ?? 0;
        $sakit = $rekapAbsen['Sakit'] ?? 0;
        $alpa = $rekapAbsen['Alpa'] ?? 0;

        if ($request->has('print') && $request->print == 'true') {
            return view('admin.reports.cetak', compact('siswa', 'tahunAktif', 'nilaiKekhasan'));
        }

        return view('admin.reports.raport', compact('siswa', 'tahunAktif', 'nilaiKekhasan'));
    }
}