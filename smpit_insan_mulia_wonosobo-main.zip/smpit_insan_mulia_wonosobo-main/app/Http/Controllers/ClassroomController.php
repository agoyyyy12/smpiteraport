<?php

namespace App\Http\Controllers;

use App\Models\Kelas;
use App\Models\Guru;
use Illuminate\Http\Request;

class ClassroomController extends Controller
{
    public function index(Request $request)
    {
        $query = Kelas::with('waliKelas')->latest();

        if ($request->filled('search')) {
            $query->where('nama', 'like', '%' . $request->search . '%');
        }

        if ($request->filled('tingkat')) {
            $query->where('tingkat', $request->tingkat);
        }

        $kelas = $query->get();

        return view('admin.classrooms.index', compact('kelas'));
    }

    public function create()
    {
        $gurus = Guru::with('user')->get();
        $existingClasses = Kelas::select('nama')->distinct()->pluck('nama');

        return view('admin.classrooms.create', compact('gurus', 'existingClasses'));
    }

    public function store(Request $request)
    {
        $namaKelas = $request->nama === 'MANUAL' ? $request->manual_nama : $request->nama;

        $request->merge(['nama' => $namaKelas]);

        $request->validate([
            'nama' => 'required|string|max:255|unique:kelas,nama',
            'tingkat' => 'required|integer',
            'wali_kelas_id' => 'nullable|exists:gurus,id',
        ]);

        Kelas::create([
            'nama' => ucwords(strtolower(trim($request->nama))),
            'tingkat' => $request->tingkat,
            'wali_kelas_id' => $request->wali_kelas_id,
        ]);

        return redirect()->route('admin.classrooms.index')->with('success', 'Data kelas berhasil ditambahkan.');
    }

    public function edit(Kelas $classroom)
    {
        $gurus = Guru::with('user')->get();
        $existingClasses = Kelas::select('nama')->distinct()->pluck('nama');

        return view('admin.classrooms.edit', compact('classroom', 'gurus', 'existingClasses'));
    }

    public function update(Request $request, Kelas $classroom)
    {
        $namaKelas = $request->nama === 'MANUAL' ? $request->manual_nama : $request->nama;

        $request->merge(['nama' => $namaKelas]);

        $request->validate([
            'nama' => 'required|string|max:255|unique:kelas,nama,' . $classroom->id,
            'tingkat' => 'required|integer',
            'wali_kelas_id' => 'nullable|exists:gurus,id',
        ]);

        $classroom->update([
            'nama' => ucwords(strtolower(trim($request->nama))),
            'tingkat' => $request->tingkat,
            'wali_kelas_id' => $request->wali_kelas_id,
        ]);

        return redirect()->route('admin.classrooms.index')->with('success', 'Data kelas berhasil diperbarui.');
    }

    public function destroy(Kelas $classroom)
    {
        $classroom->delete();

        return redirect()->route('admin.classrooms.index')->with('success', 'Data kelas berhasil dihapus.');
    }
}